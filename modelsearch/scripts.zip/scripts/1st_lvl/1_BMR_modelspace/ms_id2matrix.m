function M = ms_id2matrix( id, n, nodiag )

if nodiag
    M = zeros(n);
else
    M = eye(n);
end

e = eye(n);
mask = e(:)';

for i = 1:n*n
    if mask(i) 
        continue
    end
    idx = n*n - (i-1);
    M(idx) = rem(id, 2);
    id = floor(id/2);
end

end
