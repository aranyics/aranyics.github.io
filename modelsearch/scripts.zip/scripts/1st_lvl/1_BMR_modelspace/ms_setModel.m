function DCM = ms_setModel(tDCM, A, B1, B2, B3)

DCM = tDCM;

DCM.a = ms_id2matrix(A, 3, false);
DCM.b(:,:,1) = ms_id2matrix(B1, 3, true);
DCM.b(:,:,2) = ms_id2matrix(B2, 3, true);
DCM.b(:,:,3) = ms_id2matrix(B3, 3, true);

end
