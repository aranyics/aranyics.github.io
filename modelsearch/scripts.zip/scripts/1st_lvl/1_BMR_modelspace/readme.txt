1. Run ms_BMR_mxlist.m in matlab
