function mID = ms_id2mid(a, b1, b2, b3)


mID = b3 + b2*100 + b1*10000 + a*1000000;


end