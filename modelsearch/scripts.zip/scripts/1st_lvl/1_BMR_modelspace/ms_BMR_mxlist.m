scriptdir = fileparts( mfilename('fullpath') );
addpath(scriptdir);

subject = 's10';
Amask = [0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 0];
Abase = [1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1];
Bmask = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0; ...
         1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1; ...
         1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1];
digits = 3;

load( fullfile(scriptdir, '../../../data/DCM', strcat('DCM_', subject, '.mat')) );
baseDCM = DCM;
newDCM = baseDCM;

load( fullfile(scriptdir, '../../../data/DCM_estimated', strcat('DCM_', subject, '.mat')) );
startDCM = DCM;

outdir = fullfile(scriptdir, '../../../results/modelspace', strcat('vdmodel_4node_', subject), 'bmr_ms');
mkdir(outdir);
outcsv = fullfile(outdir, 'fullspace_bmr.csv');
fid = fopen(outcsv, 'w');

mxdir = fullfile(scriptdir, '../../../data/mx');
Amx = dir( fullfile(mxdir, 'A*') );
Bmx = dir( fullfile(mxdir, 'B*') );


for i = 1:length(Amx)
    
    fprintf('.');
    
    Aid = fopen(fullfile(Amx(i).folder, Amx(i).name), 'r');
    As = textscan( Aid, '%s', 'Delimiter', '\n' ); As = As{1};
    fclose(Aid);
    Bid = fopen(fullfile(Bmx(i).folder, Bmx(i).name), 'r');
    Bs = textscan( Bid, '%s', 'Delimiter', '\n' ); Bs = Bs{1};
    fclose(Bid);
    
    for j = 1:length(As)
        
        Ass = As{j};
        n = sqrt(length(Ass)-2);
        Assx = reshape( str2num(Ass(2:(end-1))'), n, n );
        Bss = Bs{j};
        m = (length(Bss)-2) / (n*n);
        Bssx = reshape( str2num(Bss(2:(end-1))'), n, n, m );
        
        %TODO create aid, bid, cid to be easily generated
        aid = ms_mask_matrix2id(Assx, Amask, digits);
        bid = {};
        for k = 1:m
            bid{k} = ms_mask_matrix2id(Bssx(:,:,k), Bmask(k,:), digits);
        end
        cid = "000";
        
        
        newDCM.a = Assx;
        newDCM.b = Bssx;
        
        RCM = spm_dcm_bmr({startDCM, newDCM});
        
        
        fprintf(fid, '%s,%s,%s,', aid, bid{:}, cid);
        fprintf(fid, '%f,', round(RCM{2}.F, 6));
        EA  = RCM{2}.Ep.A(:)'; PA = RCM{2}.Pp.A(:)'; PA(isnan(PA)) = 0.0;
        fprintf(fid, '%f,%f,', EA, PA);
        %results = [aid, bid{:}, cid, RCM{2}.F EA PA];
        for k = 1:m
            etmp = RCM{2}.Ep.B(:,:,k);
            ptmp = RCM{2}.Pp.B(:,:,k); ptmp(isnan(ptmp)) = 0.0;
            fprintf(fid, '%f,%f,', etmp(:)', ptmp(:)');
            %results = [results etmp(:)' ptmp(:)'];
        end
        EC  = RCM{2}.Ep.C(:)'; PC = RCM{2}.Pp.C(:)'; PC(isnan(PC)) = 0.0;
        fprintf(fid, '%f,%f,', EC, PC);
        fprintf(fid, '\n');
        
        %results = [results EC PC];

        %results(isnan(results)) = 0;
        %dlmwrite(outcsv, results, '-append', 'delimiter', ',');
    end
   
end

fclose(fid);
fprintf('\n');
