addpath('/mnt/raid6_data/user/aranyics/rdcm/etc/bmr_ms');

load('/mnt/raid6_data/user/aranyics/rdcm/DCM_att_3final.mat');
baseDCM = DCM;
newDCM = baseDCM;

%refmID = 63266158;
refb(:,:,1) = ms_id2matrix(26, 3, false);
refb(:,:,2) = ms_id2matrix(61, 3, false);
refb(:,:,3) = ms_id2matrix(58, 3, false);


for i = 1:27
    
if refb(i)
    continue
end

i

startDCM = baseDCM;
startDCM.a = ms_id2matrix(63, 3, false);
startDCM.b(:,:,1) = ms_id2matrix(63, 3, true);
startDCM.b(:,:,2) = ms_id2matrix(63, 3, true);
startDCM.b(:,:,3) = ms_id2matrix(63, 3, true);
startDCM.b(i) = 0;

startDCM = spm_dcm_estimate(startDCM);

headercsv = '/mnt/raid6_data/user/aranyics/rdcm/etc/bmr_ms/fullspace_bmr_header.csv';
outcsv = strcat('/mnt/raid6_data/user/aranyics/rdcm/etc/bmr_ms/fullspace_noconn', num2str(i), '_bmr.csv');
copyfile( headercsv, outcsv );

for a = 0:63
    mA = ms_id2matrix(a, 3, false);
    if any(any( (startDCM.a - mA) < 0 ))
        continue
    end
    for b1 = 0:63
        mB1 = ms_id2matrix(b1, 3, true);
        if ( any(any( (mA - mB1) < 0 )) || any(any( (startDCM.b(:,:,1) - mB1) < 0 )) )
            continue
        end
        for b2 = 0:63
            mB2 = ms_id2matrix(b2, 3, true);
            if ( any(any( (mA - mB2) < 0 )) || any(any( (startDCM.b(:,:,2) - mB2) < 0 )) )
                continue
            end
            for b3 = 0:63
                mB3 = ms_id2matrix(b3, 3, true);
                if ( any(any( (mA - mB3) < 0 )) || any(any( (startDCM.b(:,:,3) - mB3) < 0 )) )
                    continue
                end
                
                newDCM.a = mA;
                newDCM.b(:,:,1) = mB1;
                newDCM.b(:,:,2) = mB2;
                newDCM.b(:,:,3) = mB3;
                
                RCM = spm_dcm_bmr({startDCM, newDCM});
                
                EA  = RCM{2}.Ep.A; PA = RCM{2}.Pp.A;
                EB1 = RCM{2}.Ep.B(:,:,1); PB1 = RCM{2}.Pp.B(:,:,1);
                EB2 = RCM{2}.Ep.B(:,:,2); PB2 = RCM{2}.Pp.B(:,:,2);
                EB3 = RCM{2}.Ep.B(:,:,3); PB3 = RCM{2}.Pp.B(:,:,3);
                EC  = RCM{2}.Ep.C; PC = RCM{2}.Pp.C;
                
                results = [a b1 b2 b3 0 RCM{2}.F EA(:)' PA(:)' EB1(:)' PB1(:)' EB2(:)' PB2(:)' EB3(:)' PB3(:)' EC(:)' PC(:)'];
                results(isnan(results)) = 0;
                dlmwrite(outcsv, results, '-append', 'delimiter', ',');
                
            end
        end
    end
end


end
