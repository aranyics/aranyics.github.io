function id = ms_matrix2id(A)

n = size(A,1);
s = n*n;
e = s - n - 1;

id = 0;

for k = 1:s
    if rem(k, n+1) == 1
        continue
    end
    id = id + A(k) * 2^e;
    e = e - 1;
end

end
