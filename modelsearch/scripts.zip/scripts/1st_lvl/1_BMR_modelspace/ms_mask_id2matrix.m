function [M] = ms_mask_id2matrix(id, mask, varargin)

    Mv = dec2bin( str2num(id) );
    l = sqrt(length(mask(:))); % Note: assumes square matrix
    
    % check if binary length is more than masked elements, if so, returns 0
    if length(Mv) > length(find(mask))
        M = reshape(mask, l, l) .* 0;
        return
    end
    
    % completes binary vector to match number of masked elements
    for d = length(Mv):(length(find(mask))-1)
        Mv = strcat('0', Mv);
    end
    
    % binary string to numeric binary vector
    Mv = str2num( Mv' )';
    
    % replace masked elements with binary vector of model id
    M = mask;
    M(mask == 1) = Mv;
    
    % add base matrix (must be disjunct to masked matrix)
    if length(varargin) > 0
        M = M + varargin{1};
    end
    
    M = reshape(M, l, l);

end
