function [id] = ms_mask_matrix2id(M, mask, digits)

    Mv = M(:);
    mask = mask(:);
    
    id = Mv(mask == 1)';
    id = num2str(id);
    id = id(~isspace(id));
    id = num2str( bin2dec(id) );
    
    for d = length(id):(digits-1)
        id = strcat('0', id);
    end

end
