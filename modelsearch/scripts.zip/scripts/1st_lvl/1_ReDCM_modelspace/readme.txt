First:  ReDCM-run.sh subj                (estimate modelspace)
Second: redcm_modelspace_mxlist.sh subj  (merge results into csv)
