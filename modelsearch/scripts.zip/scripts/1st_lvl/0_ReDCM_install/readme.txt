1. run setup.sh to install all packages for R and ReDCM
Note: if R is already installed, only run packages.R