#require('Matrix')
require('plyr')
require('corrplot')
require('stringr')
require('ggplot2')
require('reshape2')
require('gplots')
require('ReDCM')

source( "~/R/wgraph/wgraph.laplacian.r" )


rdcm.ms.project.dir = '/mnt/raid6_data/user/aranyics/rdcm/fullspace_3node/'
rdcm.ms.data = '/mnt/raid6_data/user/aranyics/modelspace/fullspace/fullspace_3node.csv'
rdcm.ms.data.prep = '/mnt/raid6_data/user/aranyics/modelspace/fullspace/fullspace_3node_prepared.csv'
rdcm.ms.data2 = '/mnt/raid6_data/user/aranyics/modelspace/fullspace/fullspace_3node_dpar2.csv'
rdcm.ms.dcm.data = '/mnt/raid6_data/user/aranyics/rdcm/fullspace_3node/dcm/'
rdcm.ms.ges.path = '/mnt/raid6_data/user/aranyics/modelspace/ges/'
rdcm.ms.graph.out = '/mnt/raid6_data/user/aranyics/modelspace/graphics/'
rdcm.ms.ga.results = '/mnt/raid6_data/user/aranyics/modelspace/search/GA/Q_GApc_1000.csv'

rdcm.ms.data.bmr = '/mnt/raid6_data/user/aranyics/rdcm/etc/bmr_ms/fullspace_bmr_prepared.csv'

rdcm.ms.default.nodecount = 3
rdcm.ms.default.inputs = 3
rdcm.ms.default.inputregion = 1

rdcm.ms.friston.mID = 45003201
rdcm.ms.friston.sn = 70707
rdcm.ms.best.mID = 63265119
rdcm.ms.best.sn = 379077
rdcm.ms.best.bmr.mID = 63266158
rdcm.ms.full.mID = 63636363
rdcm.ms.search.mID = 63272161


rdcm.ms.read.data = function( csvfile, n=rdcm.ms.default.nodecount, direct=rdcm.ms.default.inputregion, isol=F )
{
  
  df = read.table(csvfile, header=TRUE, sep=',', stringsAsFactors=FALSE)
  
  if( isol )
  {
    isol = rdcm.ms.isolated.matrices(n, direct)
    df = df[aaply(df$A, 1, function(x){any(x==isol)} ),]
  }
  
  return( df )
  
}

######################################################################
# Function:
#     rdcm.ms.data.prepare
# Description:
#     Reads, and sorts raw model space data.csv
######################################################################
rdcm.ms.data.prepare = function( csvfile, n=rdcm.ms.default.nodecount, direct=rdcm.ms.default.inputregion, isol=F )
{
  
  if ( class(csvfile) == "data.frame" )
  {
    return( csvfile )
  }
  else
  {
    df = rdcm.ms.read.data( csvfile, n, direct, isol )
    if ( ! ("mID" %in% colnames(df)) )
      df = rdcm.ms.modelID( df )
    if (   ("bitvector" %in% colnames(df)) )
      df$bitvector = sub('b','',df$bitvector)
      
    df = rdcm.ms.sort( df )
  }
  
}

######################################################################
# Function:
#     rdcm.ms.model.goodness
# Description:
#     Compute model goodness (Free energy distance from best model)
######################################################################
rdcm.ms.model.goodness = function( ms.data )
{
  
  df = ms.data
  
  G = sqrt(( df$Fe - max(df$Fe) )^2)
  
  df = data.frame( df, G=G )
  
  return( df )
  
}

rdcm.ms.dFe = function( ms.data )
{

  df = ms.data
  
  dFe = max(df$Fe) - df$Fe
  
  df = data.frame( df, dFe = dFe )
  
  return( df )

}


rdcm.ms.write.data = function( df, csvfile )
{
  
  write.table( df, csvfile, row.names=FALSE, sep=',' )
  
  return( csvfile )
  
}


######################################################################
# Function:
#     rdcm.ms.id2matrix
# Description:
#     Returns the connectivity matrix corresponding to matrix ID x.
# Parameters:
#     x       - matrix ID
#     n       - number of regions
#     nodiag  - (logical) set or unset diagonal (def:FALSE)
# Output:
#     M       - connectivity matrix
######################################################################
rdcm.ms.id2matrix = function( x, n=rdcm.ms.default.nodecount, nodiag=FALSE )
{
  
  l = n*n - n
  A = array( 0, l )
  M = diag(n)
  
  for ( i in 1:l )
  {
    A[i] = x %% 2; x = floor( x / 2 );
  }
  A = rev(A)
  
  M[which(M!=1)] = A
  
  if ( nodiag )
  {
    M = M - diag(n)
  }
  
  return( M )
  
}


rdcm.ms.mID2matrix = function( mID, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs, nodiag=FALSE )
{
  
  mx.codesize = ceil(log10(2^(n*n-n)))
  structure = array(0,dim=c(n, n, u+1))
  
  for ( i in u:0 )
  {
    m = floor(mID / 10^(mx.codesize*i))
    structure[,,u-i+1] = rdcm.ms.id2matrix(m, n, nodiag)
    mID = mID - m*10^(mx.codesize*i)
  }
  
  return(structure)

}


######################################################################
# Function:
#     rdcm.ms.matrix2id
# Description:
#     Returns the matrix ID for connectivity matrix M.
# Parameters:
#     M       - connectivity matrix
# Output:
#     x       - matrix ID
######################################################################
rdcm.ms.matrix2id = function( M )
{
  
  l = length(M)
  D = diag(sqrt(l))
  M = as.logical(M)*1
  M = rev( M )
  M = M[-which(D==1)]
  x=0
  
  for ( i in 1:length(M) )
  {
    x = x + M[i] * 2^(i-1)
  }
  
  return( x )
  
}


######################################################################
# Function:
#     rdcm.ms.isolated.matrices
# Description:
#     Returns the list of matrix ID's where the region with
#     direct input is connected/disconnected with other regions.
# Parameters:
#     n         - number of regions
#     direct    - region with direct input (DCM C-matrix entry)
#     connected - (logical) returns the connected/disconnected models
# Output:
#     vector of matrix ID's
######################################################################
rdcm.ms.isolated.matrices = function( n, direct, connected=T )
{

  l = n*n - n
  interval = 0:(2^l-1)

  if ( connected )
    return( which( aaply(interval, 1, function(x){ !any(colSums(rdcm.ms.id2matrix(x,n,T))[direct] == 0 ) }) ) - 1 )
  else
    return( which( aaply(interval, 1, function(x){ any(colSums(rdcm.ms.id2matrix(x,n,T))[direct] == 0 ) }) ) - 1 )
  
}


######################################################################
# Function:
#     rdcm.ms.relevant.matrices
# Description:
#     Returns the list of matrix ID's where the relevant
#     connection is set/unset.
# Parameters:
#     n         - number of regions
#     conn      - relevant connection
#     set       - (logical) returns the models with conn set/unset
# Output:
#     vector of matrix ID's
######################################################################
rdcm.ms.relevant.matrices = function( n, conn, set=T )
{

  l = n*n - n
  interval = 0:(2^l-1)
  d = seq(1,n*n)[-which( diag(n)==1 )]
  
  conn = d[conn]
  
  if ( set )
    return( which( aaply(interval, 1, function(x){ rdcm.ms.id2matrix(x,n,T)[conn] == 1 }) ) - 1 )
  else
    return( which( aaply(interval, 1, function(x){ rdcm.ms.id2matrix(x,n,T)[conn] == 0 }) ) - 1 )
  
}


######################################################################
# Function:
#     rdcm.ms.subset
# Description:
#     Creates a subset of the input modelspace data.frame by 
#     the specified column and list of models
# Parameters:
#     df        - input modelspace data.frame
#     column    - selected column for subsetting
#     models    - vector of values to be selected in the column
# Output:
#     df2       - subsetted modelspace data.frame
######################################################################
rdcm.ms.subset = function( df, column, models )
{
  
  column = eval(substitute(column), df, parent.frame())
  models = eval(models)
  
  if ( class(column) == "name" )
  {
    column = eval(substitute(column), df, parent.frame())
  }
  
  if ( length(models) == 1 )
  {
    df2 = df[which(column == models),]
  }
  else
  {
    df2 = df[aaply(column, 1, function(x){any(x==models)} ),]
  }
  
  return( df2 )
  
}


######################################################################
# Function:
#     rdcm.ms.subset.top
# Description:
#     Creates a subset of the input modelspace data.frame by 
#     the top free energy values
# Parameters:
#     df        - input modelspace data.frame
#     top       - number of top models selected
# Output:
#     df2       - subsetted modelspace data.frame
######################################################################
rdcm.ms.subset.top = function( df, top )
{

  df = rdcm.ms.sort( df )
  
  return( df[1:top,] )

}


rdcm.ms.sort = function( df, column=NULL, decr=T )
{
  
  column = eval(substitute(column), df, parent.frame())
  
  if (is.null(column))
  {
    return( df[order(df$Fe, decreasing=decr),] )
  }
  else
  {    
    if ( class(column) == "name" )
    {
      column = eval(substitute(column), df, parent.frame())
    }
  
    return( df[order(column, decreasing=decr),] )
  }

}


rdcm.ms.matrix.paired = function( csvfile, mx1, mx2, func, top=0, cplot=FALSE, lplot=FALSE )
{

  mx1 = deparse(substitute(mx1))
  mx2 = deparse(substitute(mx2))
  
  df = rdcm.ms.read.data( csvfile )
  n = max(df$A) + 1
  pair = array(0, dim=c(n,n))
  
  df$Fe = df$Fe - min(df$Fe)
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  for ( i in 0:(n-1) )
  {
    sdf = rdcm.ms.subset( df, as.name(mx1), i )
    for ( j in 0:(n-1) )
    {
      ssdf = rdcm.ms.subset( sdf, as.name(mx2), j )
      pair[j+1,i+1] = func( ssdf$Fe )
    }
  }
  
  pair[which(is.nan(pair))] = 0
  pair[which(is.na(pair))] = 0
  
  if(cplot)
  {
    pair = pair - min(pair[which(pair>0)])
    pair[which(pair==min(pair))] = 0
    pair = pair / max(pair)
    corrplot(pair)
  }
  if(lplot)
  {
    plot( pair[,n], type='l', lwd=2 )
  }
  
  return( pair )
  
}


rdcm.ms.conn.paired = function( csvfile, n, mx1, mx2, func, top=0, cplot=FALSE, lplot=FALSE )
{

  mx1 = deparse(substitute(mx1))
  mx2 = deparse(substitute(mx2))
  
  df = rdcm.ms.read.data( csvfile )
  m = n
  n = n*n-n
  pair = array(0, dim=c(2*n,2*n))
  
  df$Fe = df$Fe - min(df$Fe)
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  for ( i in 1:n )
  {
    sdf = rdcm.ms.subset( df, as.name(mx1), rdcm.ms.relevant.matrices(m, i, F) )
    for ( j in 1:n )
    {
      ssdf = rdcm.ms.subset( sdf, as.name(mx2), rdcm.ms.relevant.matrices(m, j, F) )
      pair[(2*n+1)-j,i] = func( ssdf$Fe )
    }
  }
  for ( i in 1:n )
  {
    sdf = rdcm.ms.subset( df, as.name(mx1), rdcm.ms.relevant.matrices(m, i, T) )
    for ( j in 1:n )
    {
      ssdf = rdcm.ms.subset( sdf, as.name(mx2), rdcm.ms.relevant.matrices(m, j, F) )
      pair[(2*n+1)-j,n+i] = func( ssdf$Fe )
    }
  }
  for ( i in 1:n )
  {
    sdf = rdcm.ms.subset( df, as.name(mx1), rdcm.ms.relevant.matrices(m, i, F) )
    for ( j in 1:n )
    {
      ssdf = rdcm.ms.subset( sdf, as.name(mx2), rdcm.ms.relevant.matrices(m, j, T) )
      pair[(n+1)-j,i] = func( ssdf$Fe )
    }
  }
  for ( i in 1:n )
  {
    sdf = rdcm.ms.subset( df, as.name(mx1), rdcm.ms.relevant.matrices(m, i, T) )
    for ( j in 1:n )
    {
      ssdf = rdcm.ms.subset( sdf, as.name(mx2), rdcm.ms.relevant.matrices(m, j, T) )
      pair[(n+1)-j,n+i] = func( ssdf$Fe )
    }
  }
  
  pair[which(is.nan(pair))] = 0
  pair[which(is.na(pair))] = 0
  
  if(cplot)
  {
    pair = pair - min(pair[which(pair>0)])
    pair[which(pair==min(pair))] = 0
    pair = pair / max(pair)
    corrplot(pair)
  }
  if(lplot)
  {
    plot( pair[,n], type='l', lwd=2 )
  }
  
  return( pair )
  
}


rdcm.ms.matrix.plot = function( csvfile, mx, func=NULL, top=0, lplot=FALSE )
{

  mx = deparse(substitute(mx))
  
  df = rdcm.ms.read.data( csvfile )
  n = max(df$A) + 1
  arr = array(0, dim=n)
  
  df$Fe = df$Fe - min(df$Fe)
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  for (i in 0:(n-1))
  {
    sdf = rdcm.ms.subset( df, as.name(mx), i )
    if ( is.null(func) )
    {
      arr[i+1] = dim( sdf )[1]
    }
    else
    {
      arr[i+1] = func( sdf$Fe )
    }
  }
  
  if(lplot)
  {
    plot( arr, type='l', lwd=2 )
  }
  
  return( arr )

}


rdcm.ms.conn.plot = function( csvfile, n, mx, func=NULL, top=0, lplot=FALSE, conn.set=T )
{
  
  mx = deparse(substitute(mx))
  
  df = rdcm.ms.read.data( csvfile )
  m = n
  n = n*n-n
  arr = array(0, dim=n)
  
  df$Fe = df$Fe - min(df$Fe)
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  for (i in 1:n)
  {
    sdf = rdcm.ms.subset( df, as.name(mx), rdcm.ms.relevant.matrices( m, i, conn.set ) )
    if ( is.null(func) )
    {
      arr[i] = dim( sdf )[1]
    }
    else
    {
      arr[i] = func( sdf$Fe )
    }
  }
  
  if(lplot)
  {
    plot( arr, type='l', lwd=2 )
  }
  
  return( arr )
  
}


rdcm.ms.bayes.factor = function( df, ref='min' )
{

  if (ref == 'min')
  {
    ref = min(df$Fe)
  }
  else if (ref == 'max')
  {
    ref = max(df$Fe)
  }
  
  df = data.frame( df, BF=ref/df$Fe )
  
  return( df )

}


#rdcm.ms.hist = function( csvfile, bayes.factor=FALSE, ref='min', breaks=200, xlim=c(-4200,-3300), ... )
rdcm.ms.hist = function( csvfile, bayes.factor=FALSE, ref='min', breaks=200, xlim=c(0,1000), ... )
{

#   if ( class(csvfile) == "data.frame" )
#   {
#     df = csvfile
#   }
#   else
#   {
#     if ( exists('n') && exists('direct') )
#       df = rdcm.ms.read.data( csvfile, n, direct, T )
#     else
#       df = rdcm.ms.read.data( csvfile )
#   }
  
  df = rdcm.ms.data.prepare( csvfile )
  
  if ( bayes.factor )
  {
    df = rdcm.ms.bayes.factor( df,  ref )
    hist( df$BF, breaks=breaks, xlim=eval(call(ref, df$Fe))/xlim, xlab=str_c("Bayes Factor (relative to ", ref, ")", sep=''), ylab=" ", main="Full modelspace\nBayes Factor" )
  }
  else
  {
    df = df[df$dFe>xlim[1] & df$dFe<xlim[2],]
    gp = ggplot( df, aes(dH) ) + geom_histogram(binwidth=1)
    gp
    #hist( df$Fe[df$Fe>xlim[1] & df$Fe<xlim[2]], breaks=breaks, xlim=xlim, xlab="neg. Free energy", ylab=" ", main="Full modelspace\nFree energy" )
  }

}


rdcm.ms.hist.highlight <- function(x, value, col.value, col=NA, miscfn=NULL, ...){
  hst <- hist(x, ...)
  idx <- findInterval(value, hst$breaks, all.inside=TRUE)
  idx[which(idx == 1)] = -Inf
  cols <- rep(col, length(hst$counts))
  cols[idx] <- col.value
  
  pdf(str_c(rdcm.ms.graph.out, 'rdcm.ms.search.hist.', miscfn, '.pdf'), width=10, height=7)
  hist(x, col=cols, ...)
  text(hst$mids[idx],max(hst$counts),labels=1:length(value), adj=c(0.5, -0.5), cex=0.7)
  text(hst$mids[idx],0,labels=value, adj=c(0.5, 1.2), cex=0.7)
  dev.off()
}


rdcm.ms.search.hist = function( csvfile, searchfile, searchfile2='optional', n=rdcm.ms.default.nodecount, direct=rdcm.ms.default.inputregion, breaks=200, xlim=c(-4200,-3300), miscfn=NULL )
{

  df = rdcm.ms.data.prepare( csvfile, n, direct, T )
  sr = rdcm.ms.data.prepare( searchfile )
  if ( searchfile2 != 'optional' )
  {
    sr2 = rdcm.ms.data.prepare( searchfile2 )
    sr = rbind( sr, sr2 )
    rm(sr2)
  }
  
  df = df[which(df$Fe > xlim[1]),]
  df = df[which(df$Fe < xlim[2]),]
  
  rdcm.ms.hist.highlight(df$Fe, round(sr$Fe), 'red', breaks=breaks, xlim=xlim, xlab="-E", ylab="Model Count", main="Greedy Equivalent Search (GES) steps\non full modelspace", miscfn=miscfn)
  
}


rdcm.ms.plot.5D = function( csvfile, top=1000 )
{
  
  if ( class(csvfile) == "data.frame" )
  {
    df = csvfile
  }
  else
  {
    df = rdcm.ms.read.data( csvfile )
  }
  
  if ( dim(df)[2] == 6 )
  {
    df = df[,-1]
  }
  
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  p = ggplot(df, aes(x=Fe, y=A, fill=B2, color=B3, size=B1))
  p = p + geom_point(shape=21)
  p = p + scale_color_gradient(low="red", high="green")
  p = p + scale_size_continuous(range=c(1,12))
  
  df$B2.cat <- cut(df$B2, quantile(df$B2, (0:5)/5), include.lowest=T, )
  df$B3.cat <- cut(df$B3, quantile(df$B3, (0:5)/5), include.lowest=T)
  
  p = ggplot(df, aes(x=B1, y=A, fill=B2, color=B3, size=Fe)) +
    geom_point(shape=21) +
    scale_color_gradient(low="red", high="green") +
    scale_size_continuous(range=c(1,12)) +
    facet_grid(B2.cat ~ B3.cat)
  
  p
  
}


rdcm.ms.model.distance = function( id1, id2, n, method='xor' )
{
  
  mx1 = rdcm.ms.id2matrix(id1, n, T)
  mx2 = rdcm.ms.id2matrix(id2, n, T)

  if (method == 'xor')
  {
    dist = sum( xor(mx1, mx2)*1 )
  }
  
  return( dist )

}


rdcm.ms.model.distance.table = function( n, method='xor' )
{

  l = 2^(n*n-n)
  t = array(0, l)
  
  for ( i in 1:l )
  {
    t[i] = rdcm.ms.model.distance( 0, i-1, n, method )
  }

  return( t )
  
}


rdcm.ms.distance.space = function( csvfile, n=rdcm.ms.default.nodecount, method='xor', top=0 )
{
  
  df = rdcm.ms.data.prepare(csvfile)
  
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  tab = rdcm.ms.model.distance.table( n, method )
  
  df = data.frame( df, dA=tab[df$A+1], dB1=tab[df$B1+1], dB2=tab[df$B2+1], dB3=tab[df$B3+1], dM=tab[df$A+1]+tab[df$B1+1]+tab[df$B2+1]+tab[df$B3+1] )
  
  return( df )

}


rdcm.ms.plot.by.distance = function( csvfile, n=rdcm.ms.default.nodecount, mx=M, func=NULL, method='xor', top=0, lplot=FALSE )
{

  if ( class(csvfile) == "data.frame" )
  {
    df = csvfile
  }
  else
  {
    df = rdcm.ms.read.data( csvfile )
  }
  
  if (top > 0)
  {
    df = rdcm.ms.subset.top(df, top)
  }
  
  df = rdcm.ms.distance.space( df, n, method )
  
  mx.name = deparse(substitute(mx))
  mx = str_c( 'd', mx.name, sep='')
  mx = df[[mx]]
  
  arr = array(0, max(mx))
  arr2 = array(0, max(mx))
  for ( i in 0:max(mx) )
  {
    
    arr[i+1] = length( which(mx == i) )
    if ( !is.null(func) )
    {
      arr2[i+1] = func( df$Fe[which(mx == i)] )
    }
  }
  
  if(lplot)
  {
    if ( is.null(func) )
    {      
      #par( mfrow=c(2,1) )
      plot( arr, type='l', lwd=2 )
      #plot( mx ~ df$Fe, type='l', lwd=2 )
      #par( mfrow=c(1,1) )
    }
    else
    {
      par( mfrow=c(2,1) )
      plot( arr, type='l', lwd=2 )
      plot( arr2, type='l', lwd=2 )
      par( mfrow=c(1,1) )
    }
  }
  
  return( mean(mx) )

}


rdcm.ms.search.plot = function( csvfile, searchfile, searchfile2='optional', n=rdcm.ms.default.nodecount, mx=M, method='xor', lplot=FALSE, miscfn=NULL )
{

  df = rdcm.ms.data.prepare( csvfile )
  sr = rdcm.ms.data.prepare( searchfile )
  if ( searchfile2 != 'optional' )
  {
    sr2 = rdcm.ms.data.prepare( searchfile2 )
    sr = rbind( sr, sr2 )
    rm(sr2)
  }
  
  df = rdcm.ms.subset.top(df, top=1)
  mx = c(1:length( sr$Fe ))
  
#   df = rdcm.ms.distance.space( df, n, method )
#   sr = rdcm.ms.distance.space( sr, n, method )
#   
#   mx = str_c( 'd', deparse(substitute(mx)), sep='')
#   ref = df[[mx]]
#   mx = sr[[mx]]
  
  arr1 = array(0, length(mx))
  arr2 = array(0, length(mx))
  
  for ( i in 1:length(mx) )
  {
    #arr1[i] = abs(ref - mx[i])
    arr1[i] = rdcm.ms.model.distance(df$A[1], sr$A[i], 3) + rdcm.ms.model.distance(df$B1[1], sr$B1[i], 3) + rdcm.ms.model.distance(df$B2[1], sr$B2[i], 3) + rdcm.ms.model.distance(df$B3[1], sr$B3[i], 3)
    arr2[i] = df$Fe[1] - sr$Fe[i]
  }
  
  if(lplot)
  {
    par( mfrow=c(2,1) )
    plot( arr1, type='l', lwd=2 )
    plot( arr2, type='l', lwd=2 )
    par( mfrow=c(1,1) )
  }
  else #ggplot
  {
    gdf = data.frame(Distance=arr1, dE=arr2)
    gdf = melt(gdf)
    gdf = data.frame(id=c(1:length(arr1)), gdf)
    p = ggplot(gdf, aes(x=id, y=value)) +
      geom_line(lwd=1.5, color="#2b6e87") +
      geom_point(size=3, color="#052c3b") +
      facet_grid(variable ~ ., scales='free_y') +
      scale_x_continuous(breaks=gdf$id) +
      xlab("Iteration") +
      ylab(" ") +
      ggtitle("Characteristics of model search algorithm GES_bw") +
      theme(
            strip.text.y = element_text(size=18),
            strip.background = element_rect(fill="#cccccc"),
            axis.text=element_text(size=18),
            axis.title=element_text(size=20,face="bold"))
    
    p
    
    ggsave(str_c(rdcm.ms.graph.out, 'rdcm.ms.search.plot.', miscfn, '.pdf'), width=9, height=6)
  }

}


# rdcm.ms.data.prepare = function( csvfile, n=rdcm.ms.default.nodecount, direct=rdcm.ms.default.inputregion, isol=F )
# {
# 
#   if ( class(csvfile) == "data.frame" )
#   {
#     return( csvfile )
#   }
#   else
#   {
#     return( rdcm.ms.read.data( csvfile, n, direct, isol ) )
#   }
#   
# }

thisFile <- function() {
  cmdArgs <- commandArgs(trailingOnly = FALSE)
  needle <- "--file="
  match <- grep(needle, cmdArgs)
  if (length(match) > 0) {
    # Rscript
    return(normalizePath(sub(needle, "", cmdArgs[match])))
  } else {
    # 'source'd via R console
    return(normalizePath(sys.frames()[[1]]$ofile))
  }
}

###################################################################################################

rdcm.ms.load.dcm = function( id, batchsize = 1000 )
{
  
  #thisDir = dirname( thisFile() )
  #source( '/home/aranyics/R/rdcm/R/rdcm_estimate.r' )
  setwd(rdcm.ms.dcm.data)
  
  out = 0
  
  if ( id %% batchsize == 0 )
  {
    out = (floor(id / batchsize) - 1) * 1000 + 1
  }
  else
  {
    out = (floor(id / batchsize)) * 1000 + 1
  }
  
  load( str_c( rdcm.ms.dcm.data, 'out_', out, '/DCM_', id ) )
  
  return (DCMe)

}
DCMe = rdcm.ms.load.dcm( rdcm.ms.friston.sn )

rdcm.ms.get.dcm.paramvect = function ( id )
{

  DCMe = rdcm.ms.load.dcm( id )
  
  dcm.ep = c(DCMe@Ep@A,
             DCMe@Ep@B,
             DCMe@Ep@C,
             DCMe@Ep@D,
             DCMe@Ep@transit,
             DCMe@Ep@decay,
             DCMe@Ep@epsilon)
  
  return ( list(Ep=dcm.ep,
                A=DCMe@Ep@A,
                B=DCMe@Ep@B,
                C=DCMe@Ep@C,
                D=DCMe@Ep@D,
                Ht=DCMe@Ep@transit,
                Hd=DCMe@Ep@decay,
                He=DCMe@Ep@epsilon) 
           )

}

rdcm.ms.distance.paramvect = function( csvfile )
{

  df = rdcm.ms.data.prepare( csvfile )
  rm( csvfile )
  
  ref = rdcm.ms.subset.top( df, top=1 )
  
  ref.p = rdcm.ms.get.dcm.paramvect( ref$ID )
  dif = apply(array(df$ID), 1, function(x){ tmp.p = rdcm.ms.get.dcm.paramvect(x); return( list(dP=sqrt(sum((ref.p$Ep-tmp.p$Ep)^2)),
                                                                                                    dA=sqrt(sum((ref.p$A-tmp.p$A)^2)),
                                                                                                    dB1=sqrt(sum((ref.p$B[,,1]-tmp.p$B[,,1])^2)),
                                                                                                    dB2=sqrt(sum((ref.p$B[,,2]-tmp.p$B[,,2])^2)),
                                                                                                    dB3=sqrt(sum((ref.p$B[,,3]-tmp.p$B[,,3])^2)),
                                                                                                    dC=sqrt(sum((ref.p$C-tmp.p$C)^2)),
                                                                                                    dHt=sqrt(sum((ref.p$Ht-tmp.p$Ht)^2)),
                                                                                                    dHd=sqrt(sum((ref.p$Hd-tmp.p$Hd)^2)),
                                                                                                    dHe=sqrt(sum((ref.p$He-tmp.p$He)^2)) ) ) })
  dif = matrix(unlist(dif), nrow=length(dif), byrow=TRUE)
  
  df = data.frame(df, dP=dif[,1], dA=dif[,2], dB1=dif[,3], dB2=dif[,4], dB3=dif[,5], dC=dif[,6], dHt=dif[,7], dHd=dif[,8], dHe=dif[,9])
  
  return(df)

}


rdcm.ms.write.paramvect = function( csvfile, n=rdcm.ms.default.nodecount )
{
  df = rdcm.ms.data.prepare( csvfile )
  rm(csvfile)
  
  if ( ! ("mID" %in% colnames(df)) )
    df = rdcm.ms.modelID( df )
  
  par = aaply(array(df$ID[1:5]), 1, function(x){ tmp = rdcm.ms.load.dcm(x); return( list(c(tmp@Ep@A),
                                                                                    c(tmp@Pp@A),
                                                                                    c(tmp@Ep@B[,,1]),
                                                                                    c(tmp@Pp@B[,,1]),
                                                                                    c(tmp@Ep@B[,,2]),
                                                                                    c(tmp@Pp@B[,,2]),
                                                                                    c(tmp@Ep@B[,,3]),
                                                                                    c(tmp@Pp@B[,,3]),
                                                                                    c(tmp@Ep@C),
                                                                                    c(tmp@Pp@C)) ) })
  par = round(matrix(unlist(par), ncol=n*n, byrow=TRUE), 3)
  par[is.nan(par)] = 0
  
  cn = c('mID','A_11','A_12','A_13','A_21','A_22','A_23','A_31','A_32','A_33','pA_11','pA_12','pA_13','pA_21','pA_22','pA_23','pA_31','pA_32','pA_33')
  dfpar = data.frame( df$mID, as.data.frame(par[1:dim(df)[1],]), as.data.frame( par[(dim(df)[1]+1):(2*dim(df)[1]),] ) )
  #dfpar = data.frame( df$mID, as.data.frame(t(par[1:dim(df)[1],])), as.data.frame( t(par[(dim(df)[1]+1):(2*dim(df)[1]),] )) ) #if df is 1 row long
  colnames(dfpar) = cn
  par = par[-(1:(2*dim(df)[1])),]
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/A.csv'))
  
  cn = c('mID','B1_11','B1_12','B1_13','B1_21','B1_22','B1_23','B1_31','B1_32','B1_33','pB1_11','pB1_12','pB1_13','pB1_21','pB1_22','pB1_23','pB1_31','pB1_32','pB1_33')
  dfpar = data.frame( df$mID, as.data.frame(par[1:dim(df)[1],]), as.data.frame( par[(dim(df)[1]+1):(2*dim(df)[1]),] ) )
  colnames(dfpar) = cn
  par = par[-(1:(2*dim(df)[1])),]
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/B1.csv'))
  
  cn = c('mID','B2_11','B2_12','B2_13','B2_21','B2_22','B2_23','B2_31','B2_32','B2_33','pB2_11','pB2_12','pB2_13','pB2_21','pB2_22','pB2_23','pB2_31','pB2_32','pB2_33')
  dfpar = data.frame( df$mID, as.data.frame(par[1:dim(df)[1],]), as.data.frame( par[(dim(df)[1]+1):(2*dim(df)[1]),] ) )
  colnames(dfpar) = cn
  par = par[-(1:(2*dim(df)[1])),]
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/B2.csv'))
  
  cn = c('mID','B3_11','B3_12','B3_13','B3_21','B3_22','B3_23','B3_31','B3_32','B3_33','pB3_11','pB3_12','pB3_13','pB3_21','pB3_22','pB3_23','pB3_31','pB3_32','pB3_33')
  dfpar = data.frame( df$mID, as.data.frame(par[1:dim(df)[1],]), as.data.frame( par[(dim(df)[1]+1):(2*dim(df)[1]),] ) )
  colnames(dfpar) = cn
  par = par[-(1:(2*dim(df)[1])),]
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/B3.csv'))
  
  cn = c('mID','C1_1','C1_2','C1_3','C2_1','C2_2','C2_3','C3_1','C3_2','C3_3','pC1_1','pC1_2','pC1_3','pC2_1','pC2_2','pC2_3','pC3_1','pC3_2','pC3_3')
  dfpar = data.frame( df$mID, as.data.frame(par[1:dim(df)[1],]), as.data.frame( par[(dim(df)[1]+1):(2*dim(df)[1]),] ) )
  colnames(dfpar) = cn
  par = par[-(1:(2*dim(df)[1])),]
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/C.csv'))
  
  
  return(par)
  
}

rdcm.ms.write.paramvect.hemodyn = function( csvfile, n=rdcm.ms.default.nodecount )
{
  df = rdcm.ms.data.prepare( csvfile )
  rm(csvfile)
  
  if ( ! ("mID" %in% colnames(df)) )
    df = rdcm.ms.modelID( df )
  
  par = aaply(array(df$ID), 1, function(x){ tmp = rdcm.ms.load.dcm(x); return( list(c(tmp@Ep@transit,
                                                                                         tmp@Ep@decay,
                                                                                         tmp@Ep@epsilon,
                                                                                         tmp@Pp@transit,
                                                                                         tmp@Pp@decay,
                                                                                         tmp@Pp@epsilon)
                                                                                    ) ) })
  par = round(matrix(unlist(par), ncol=14, byrow=TRUE), 4)
  par[is.nan(par)] = 0
  
  cn = c('ID','mID','T1','T2','T3','D1','D2','D3','E','pT1','pT2','pT3','pD1','pD2','pD3','pE')
  dfpar = data.frame( df$ID, df$mID, as.data.frame(par) )
  colnames(dfpar) = cn
  rdcm.ms.write.data(dfpar, str_c(rdcm.ms.project.dir, '/fullspace/H.csv'))
  
  return(par)
}


rdcm.ms.hist.paramvect = function( matrix='A', modelspace=NULL )
{
  
  if (!file.exists(str_c(rdcm.ms.project.dir, '/fullspace/', matrix, '.csv')))
  {
    cat('A.csv don\'t exist. Please, run rdcm.ms.write.paramvect first!')
    return(1)
  }
  
  weighted.mean = 0
  if (!is.null(modelspace))
  {
    modelspace = rdcm.ms.data.prepare( modelspace )
    weighted.mean = 1
  }
  
  par = rdcm.ms.read.data(str_c(rdcm.ms.project.dir, '/fullspace/', matrix, '.csv'))
  partop = data.frame( variable=colnames(par[1,2:10]), X1=t(par[1,2:10]) )
  probtop = data.frame( variable=colnames(par[1,11:19]), X1=t(par[1,11:19]) )
  
  # ggplots for parameter strength/probability histogram
  parm = melt(par[,2:10])
  parmwid = 2*round(max(parm$value)) / 25   # create ~25 bins
  if (weighted.mean)
  {
    #Fe = df$Fe - min(df$Fe)
    #Fe = Fe / max(Fe)
    Fe = seq(0.000001,1, 1/dim(df)[1])
    cdat = ddply(parm, 'variable', .fun=function(x){ c(conn.mean=mean(x$value), conn.wmean=weighted.mean(x$value, Fe), conn.sd=sd(x$value), conn.median=median(value)) } )  #we assume data.frame ordering is the same
  }
  else
  {
    cdat = ddply(parm, 'variable', summarize, conn.mean=mean(value), conn.sd=sd(value), conn.median=median(value))
  }
  g = ggplot(parm[-which(parm$value==0),], aes(x=value)) + 
    geom_histogram(aes(y=..density..), binwidth=parmwid, colour='black', fill='white') + 
    geom_density(alpha=0.2, fill='#6666FF') + 
    geom_vline(data=cdat, aes(xintercept=conn.mean), color='red', linetype='dashed', size=0.5) + 
    geom_vline(data=partop, aes(xintercept=X1), color='blue', linetype='dashed', size=0.5) + 
    geom_vline(data=cdat, aes(xintercept=conn.median), color='green', linetype='dashed', size=0.5) + 
    facet_wrap(~ variable, dir='v') +
    ggtitle(str_c(matrix, ' connection strengths'))
  g
  ggsave(str_c(rdcm.ms.project.dir, '/graphics/', matrix, 'par.pdf'), width=10, height=10)
  
  parm = melt(par[,11:19])
  if (weighted.mean)
  {
    Fe = df$Fe - min(df$Fe)
    cdat = ddply(parm, 'variable', summarize, conn.mean=mean(value * Fe/max(Fe)), conn.sd=sd(value), conn.median=median(value))               #we assume data.frame ordering is the same
  }
  else
  {
    cdat = ddply(parm, 'variable', summarize, conn.mean=mean(value), conn.sd=sd(value), conn.median=median(value))
  }
  g = ggplot(parm[-which(parm$value==0),], aes(x=value)) + 
    geom_histogram(binwidth=0.001, colour='black', fill='white') + 
    geom_vline(data=cdat, aes(xintercept=conn.mean), color='red', linetype='dashed', size=0.5) + 
    geom_vline(data=probtop, aes(xintercept=X1), color='blue', linetype='dashed', size=0.5) + 
    geom_vline(data=cdat, aes(xintercept=conn.median), color='green', linetype='dashed', size=0.5) + 
    facet_wrap(~ variable, dir='v') +
    ggtitle(str_c(matrix, ' connection probabilities'))
  g
  ggsave(str_c(rdcm.ms.project.dir, '/graphics/p', matrix, 'par.pdf'), width=10, height=10)
  
  return(0)
  
}


######################################################################
# Function:
#     rdcm.ms.modelID
# Description:
#     Constructs modelID from model matrix IDs
######################################################################
rdcm.ms.modelID = function( ms.data )
{
  
  df = ms.data
  
  mID = df$B3 + 100*df$B2 + 10000 * df$B1 + 1000000 * df$A
  
  df = data.frame( df, mID = mID )
  
  return( df )
  
}

# rdcm.ms.modelID = function( csvfile )
# {
#   
#   df = rdcm.ms.data.prepare( csvfile )
#   rm( csvfile )
#   
#   mID = df$B3 + 100*df$B2 + 10000 * df$B1 + 1000000 * df$A
#   
#   df = data.frame( df, mID = mID )
#   
#   return( df )
# 
# }

rdcm.ms.model.goodness = function( csvfile )
{

  df = rdcm.ms.data.prepare( csvfile )
  rm( csvfile )
  
  G = sqrt(( df$Fe - max(df$Fe) )^2)
  
  df = data.frame( df, G=G )
  
  return( df )

}


rdcm.ms.scatter.paramvect = function( csvfile, searchfile=NULL, density=1, splot=TRUE, miscfn=NULL )
{
  
  #csvfile need to have distance column
  
  df = rdcm.ms.data.prepare( csvfile )  
  #df = rdcm.ms.bayes.factor( df )  
  #df = rdcm.ms.sort( df )
  df = df[seq(1,dim(df)[1],1/density),]
  #df$Fe = abs( df$Fe - max(df$Fe) )
  #df$Fe = sqrt(( df$Fe - max(df$Fe) )^2)
  #df = rdcm.ms.modelID( df )
  if ( ! ("dFe" %in% colnames(df)) )
    df = rdcm.ms.dFe( df )
  if ( ! ("dH" %in% colnames(df)) )
    df = rdcm.ms.hamming( df )
  rm( csvfile )
  sr = NULL
  
  if (!is.null(searchfile))
  {
    sr = rdcm.ms.data.prepare( searchfile )
    sr = rdcm.ms.modelID( sr )
    sr = df[match(sr$mID, df$mID),]
    #return(sr)
  }
  
  if (splot)
  {
    #plot( df$dP, df$BF )
    #pdf(str_c(rdcm.ms.graph.out, 'rdcm_ms_2dhist_', miscfn, '.pdf'), width=9, height=9)
    if (!is.null(sr))
    {
      df = df[df$dP<(1.2*max(sr$dP)),]
      df = df[df$Fe<(1.2*max(sr$Fe)),]
    }
    #df = df[df$dC<0.1,]
    #df = df[df$Fe<100,] #NORMÁLNI A PARAMÉTERTÁVOLSÁGOT ÉLSŰRŰSÉGRE
    hist2d( df[df$dFe<1000,c('dH', 'dFe')], nbins=c(20,100), xlab='Hamming-distance', ylab='dFe', cex.lab=1.2 )
    #axis(side=2, at=seq(0, max(df$Fe), by=200))
    #axis(side=1, at=seq(0, max(df$dP), by=5))
    #hist2d( df[,c('dP', 'Fe')], nbins=200, xlab='Model distance', ylab='Model goodness', main='Full modelspace characteristics', axes=FALSE, cex.lab=1.5, cex.main=1.8 )
    #axis(side=2, at=seq(0, max(df$Fe), by=100))
    #axis(side=1, at=seq(0, max(df$dP), by=1))
    if (!is.null(sr))
    {
      for ( i in 1:dim(sr)[1] )
      {
        points( sr$dP[i], sr$Fe[i], lwd=25, col='green' )
      }
      points( 0, 0, lwd=40, col='red' )
      points( df[df$mID==rdcm.ms.friston,'dP'], df[df$mID==rdcm.ms.friston,'Fe'], lwd=25, col='white' )
    }
    #dev.off()
  }
  else
  {
    return( list( df, sr ) )
  }

}


rdcm.ms.laplacian.undirected.mx = function( mx )
{

  mx.dims = dim(mx)
  Z = matrix(0, 2*mx.dims[1], 2*mx.dims[2])
  mx[mx!=0] = exp(mx[mx!=0])
  Z[1:mx.dims[1],(mx.dims[2]+1):(mx.dims[2]*2)] = mx
  Z=Z+t(Z)
  i=which(rowSums(Z)==0)
  if(length(i)>0)
    Z=Z[-i,-i]
  
  return ( Z )

}


rdcm.ms.laplacian.distance = function( id1, id2, plot=FALSE )
{
  
  if ( class(id1) == "Estimates" )
    M1 = id1
  else
    M1 = rdcm.ms.load.dcm( id1 )
  
  if ( class(id2) == "Estimates" )
    M2 = id2
  else
    M2 = rdcm.ms.load.dcm( id2 )
  
  inputs = M1@M[[1]]@m
  nodes = M1@M[[1]]@l
  mxsize = nodes
  supsize = (inputs + 1) * nodes
  
  # Supermatrix
  # ---------------------------------------------
  P1 = matrix(0,supsize,supsize)
  P1[1:nodes,1:nodes] = M1@Ep@A
  for (i in 1:inputs)
  {
    P1[(i*nodes+1):((i+1)*nodes),(i*nodes+1):((i+1)*nodes)] = M1@Ep@B[,,i]
  }
  Z1 = rdcm.ms.laplacian.undirected.mx( P1 )
  
  P2 = matrix(0,supsize,supsize)
  P2[1:nodes,1:nodes] = M2@Ep@A
  for (i in 1:inputs)
  {
    P2[(i*nodes+1):((i+1)*nodes),(i*nodes+1):((i+1)*nodes)] = M2@Ep@B[,,i]
  }
  Z2 = rdcm.ms.laplacian.undirected.mx( P2 )
  
  
  # Element matrices
  # ---------------------------------------------
  A.1 = rdcm.ms.laplacian.undirected.mx( M1@Ep@A )
  B1.1 = rdcm.ms.laplacian.undirected.mx( M1@Ep@B[,,1] )
  B2.1 = rdcm.ms.laplacian.undirected.mx( M1@Ep@B[,,2] )
  B3.1 = rdcm.ms.laplacian.undirected.mx( M1@Ep@B[,,3] )
  
  A.2 = rdcm.ms.laplacian.undirected.mx( M2@Ep@A )
  B1.2 = rdcm.ms.laplacian.undirected.mx( M2@Ep@B[,,1] )
  B2.2 = rdcm.ms.laplacian.undirected.mx( M2@Ep@B[,,2] )
  B3.2 = rdcm.ms.laplacian.undirected.mx( M2@Ep@B[,,3] )
  
  dZ = dA = dB1 = dB2 = dB3 = 0;
  
  if ( length(Z1) < 1 ) dZ = Inf;
  if ( length(Z2) < 1 ) dZ = Inf;
  
  if ( length(A.1) < 1 ) dA = Inf;
  if ( length(B1.1) < 1 ) dB1 = Inf;
  if ( length(B2.1) < 1 ) dB2 = Inf;
  if ( length(B3.1) < 1 ) dB3 = Inf;
  
  if ( length(A.2) < 1 ) dA = Inf;
  if ( length(B1.2) < 1 ) dB1 = Inf;
  if ( length(B2.2) < 1 ) dB2 = Inf;
  if ( length(B3.2) < 1 ) dB3 = Inf;
  
  
  # Laplacian spectra
  # ---------------------------------------------  
  if ( is.finite(dZ) ) LZ1=wgraph.normalized.laplacian.spectra(Z1);
  if ( is.finite(dZ) ) LZ2=wgraph.normalized.laplacian.spectra(Z2);
  
  if ( is.finite(dA) ) LA.1=wgraph.normalized.laplacian.spectra(A.1);
  if ( is.finite(dB1) ) LB1.1=wgraph.normalized.laplacian.spectra(B1.1);
  if ( is.finite(dB2) ) LB2.1=wgraph.normalized.laplacian.spectra(B2.1);
  if ( is.finite(dB3) ) LB3.1=wgraph.normalized.laplacian.spectra(B3.1);
  
  if ( is.finite(dA) ) LA.2=wgraph.normalized.laplacian.spectra(A.2);
  if ( is.finite(dB1) ) LB1.2=wgraph.normalized.laplacian.spectra(B1.2);
  if ( is.finite(dB2) ) LB2.2=wgraph.normalized.laplacian.spectra(B2.2);
  if ( is.finite(dB3) ) LB3.2=wgraph.normalized.laplacian.spectra(B3.2);
  
  
  # Laplacian spectral distance
  # ---------------------------------------------  
  if ( is.finite(dZ) ) dZ = wgraph.spectral.distance(LZ1,LZ2);
  if ( is.finite(dA) ) dA = wgraph.spectral.distance(LA.1,LA.2);
  if ( is.finite(dB1) ) dB1 = wgraph.spectral.distance(LB1.1,LB1.2);
  if ( is.finite(dB2) ) dB2 = wgraph.spectral.distance(LB2.1,LB2.2);
  if ( is.finite(dB3) ) dB3 = wgraph.spectral.distance(LB3.1,LB3.2);
  
  
  # Spectral plot
  # ---------------------------------------------  
  if ( plot )
  {
    s = 2*0.015^2
    plot(wgraph.spectral.plot.from.l( LZ1, s), xaxs="i", yaxs="i", type="l", lwd=3)
    lines(wgraph.spectral.plot.from.l( LZ2, s), col="red")
    points( 0, d, pch=4, lwd=2, col="red" )
    text(30, d, labels=d, cex= 0.7, pos=4, col="red")
  }

  return ( list( dZ, dA, dB1, dB2, dB3 ) )
  
}


rdcm.ms.laplacian = function( csvfile, ref.mID=rdcm.ms.best, neigh=1000 )
{

  df = rdcm.ms.data.prepare( csvfile )
  
  if ( ! ("mID" %in% colnames(df)) )
    df = rdcm.ms.modelID( df )
  if ( ! ("G" %in% colnames(df)) )
    df = rdcm.ms.model.goodness( df )
  
  if ( neigh > 0 )
  {
    df = rdcm.ms.sort( df )
    df = df[rdcm.ms.interval.around.ref( dim(df)[1], which(df$mID==ref.mID), neigh ),]
  }
  
  Mref = rdcm.ms.load.dcm( df$ID[df$mID==ref.mID] )
  
  l.dif = apply(array(df$ID), 1, function(x){ tmp.dcm = rdcm.ms.load.dcm(x); return( rdcm.ms.laplacian.distance( Mref, tmp.dcm ) ) } )
  l.dif = t( matrix( unlist(l.dif), nrow=5) )
  
  df = data.frame( df, dLap=l.dif[,1], dLapA=l.dif[,2], dLapB1=l.dif[,3], dLapB2=l.dif[,4], dLapB3=l.dif[,5] )
  
  return( df )

}


rdcm.ms.interval.around.ref = function( data.size, ref, neigh )
{
  
  from = NULL
  to = NULL
  
  half = floor(neigh/2)

  if ( ref < (half + 1) )
  {
    from = 1
    to = neigh
  }
  else if ( ref > (data.size - (half - 1)) )
  {
    to = data.size
    from = data.size - neigh
  }
  else
  {
    from = ref - half
    to = ref + half
  }
  
  return ( c(from:to) )

}


#### 2017. 02. 03. ####################################################################

rdcm.ms.conn.exists = function( conn, n=rdcm.ms.default.nodecount, invert=FALSE )
{

  if (conn < 1 || conn > (n*n))
  {
    return ('Connection must range between 1 and (n*n)')
  }
  
  l = n*n - n
  interval = 0:(2^l-1)
  
  if( !invert )
    return( which( aaply( interval, 1, function(x){rdcm.ms.id2matrix(x)[conn] == 1} ) ) - 1 )
  else
    return( which( aaply( interval, 1, function(x){rdcm.ms.id2matrix(x)[conn] == 0} ) ) - 1 )

}

rdcm.ms.get.nondiag = function( n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs )
{

  l = n*n - n
  mID = 2^l - 1
  if (u)
  {
    for (i in 1:u)
    {
      mID = mID * 10^ceil(log10(2^l-1)) + 2^l - 1
    }
  }
  
  return( which(rdcm.ms.mID2matrix(mID, n=n, u=u, nodiag=T) == 1) )

}

rdcm.ms.hamming.distance.matrix = function( mID1, mID2, n=rdcm.ms.default.nodecount )
{
  
  return (sum( rdcm.ms.id2matrix(mID1, n) != rdcm.ms.id2matrix(mID2, n) ))
  
}

rdcm.ms.hamming.distance.model = function( mID1, mID2, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs )
{
  
  return (sum( rdcm.ms.mID2matrix(mID1, n, u) != rdcm.ms.mID2matrix(mID2, n, u) ))
  
}

rdcm.ms.hamming = function( csvfile, ref.mID=rdcm.ms.best.mID, neigh=0, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs )
{
  
  df = rdcm.ms.data.prepare( csvfile )
  rm(csvfile)
  
  if ( ! ("mID" %in% colnames(df)) )
    df = rdcm.ms.modelID( df )
  if ( ! ("G" %in% colnames(df)) )
    df = rdcm.ms.model.goodness( df )
  
  if ( neigh > 0 )
  {
    df = rdcm.ms.sort( df )
    df = df[rdcm.ms.interval.around.ref( dim(df)[1], which(df$mID==ref.mID), neigh ),]
  }
    
  h.dif = apply(array(df$mID), 1, function(x){ rdcm.ms.hamming.distance.model(x, ref.mID, n, u) } )
  
  df = data.frame( df, dH=h.dif )
  
  return( df )
  
}

rdcm.ms.family.by.connection = function( csvfile, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs )
{

  df = rdcm.ms.data.prepare( csvfile )
  rm(csvfile)
  
  groups = rdcm.ms.get.nondiag( n, 0 )
  res = NULL
  
  for ( i in groups )
  {
    t = df[(df[,2] %in% rdcm.ms.conn.exists(i)),]
    f = df[(df[,2] %in% rdcm.ms.conn.exists(i, invert=T)),]
    tmp = data.frame( mx='A', conn=i, on=mean(t$Fe), off=mean(f$Fe), diff=mean(t$Fe)-mean(f$Fe) )
    res = rbind(res, tmp)
    for ( j in 1:u )
    {
      t = df[(df[,2+j] %in% rdcm.ms.conn.exists(i)),]
      f = df[(df[,2+j] %in% rdcm.ms.conn.exists(i, invert=T)),]
      tmp = data.frame( mx=str_c('B',j, sep=''), conn=i, on=mean(t$Fe), off=mean(f$Fe), diff=mean(t$Fe)-mean(f$Fe) )
      res = rbind(res, tmp)
    }
  }
  
  return(res)

}


rdcm.ms.model.density = function ( mID, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs, nodiag=FALSE )
{
  
  max.dens = n*n*(u+1)
  if (nodiag)
  {
    max.dens = max.dens - n*(u+1)
  }
  
  m.dens = length(which( rdcm.ms.mID2matrix( mID, n, u, nodiag ) == 1 ))
  
  if (nodiag)
    return( m.dens / max.dens )
  else
    return( (m.dens-n*u) / max.dens )
  
}


rdcm.ms.density = function ( csvfile, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs )
{

  df = rdcm.ms.data.prepare( csvfile )
  rm(csvfile)
  
  dens = apply(array(df$mID), 1, function(x){ rdcm.ms.model.density(x, n, u) } )
  df = data.frame( df, density=dens )
  
  if ( ("dP" %in% colnames(df)) )
    df = data.frame( df, dPcorr=(1-dens)*df$dP )
  
  return( df )

}



#### 2017. 10. 02. ####################################################################

rdcm.ms.score.all = function(csvfile, DCMe, input.scaling=0.1, penalty=1.0)
{
  df = rdcm.ms.data.prepare(csvfile)
  ts = rdcm.ms.create.ts.init(DCMe)
  
  scores = NULL
  
  for ( mID in df$mID )
  {
    tree = rdcm.ms.create.tree(df, mID)
    ts   = rdcm.ms.create.ts(tree, ts, input.scaling=input.scaling)
    scr  = rdcm.ms.score.tree(tree, ts, penalty=penalty)
    
    scores = c(scores, scr)
  }
  
  df = data.frame(df, s.bold=scores)
  
  return(df)
}

rdcm.ms.score.tree = function(tree, ts, penalty=1.0)
{
  if( length(tree) != dim(ts)[2] )
    stop("Error: graph size and time series data mismatch")
  
  score = 0
  
  M = cov(ts)
  #Mpca = prcomp(M, scale.=FALSE)[[2]]
  n = dim(ts)[1]
  
  for( l in 1:length(tree) )
  {
    if ( is.na(tree[[l]][1]) )
      next
    
    k = (length(tree[[l]]) + 1) * (length(tree[[l]]) + 2) / 2
    residualVariance = M[l, l]
    #residualVariance = Mpca[l, 1]
    
    Mpp = M[tree[[l]], tree[[l]]]
    iMpp = pracma::inv(as.matrix(Mpp))
    Mpl = M[tree[[l]], l]
    b = iMpp %*% Mpl
    residualVariance = as.numeric(residualVariance - Mpl %*% b)
    
    if( residualVariance <= 0 )
      next
    
    score = score + (- n*log(residualVariance) - n*log(2*pi) - n - k*penalty*log(n))
  }
  
  return( score )
}

rdcm.ms.create.tree = function( csvfile, mID=rdcm.ms.friston.mID, n=rdcm.ms.default.nodecount, u=rdcm.ms.default.inputs, C=array(c(1,0,0,0,0,0,0,0,0), dim=c(3,3)) )
{
  
  if( dim(C)[1] != n | dim(C)[2] != u ) stop("Error: wrong C matrix size")
  
  df = rdcm.ms.data.prepare( csvfile )
  df = df[which(df$mID==mID),]
  A  = rdcm.ms.id2matrix(df$A,  n=n, nodiag=T)
  Av = c(A)
  B1 = c(rdcm.ms.id2matrix(df$B1, n=n, nodiag=T))
  B2 = c(rdcm.ms.id2matrix(df$B2, n=n, nodiag=T))
  B3 = c(rdcm.ms.id2matrix(df$B3, n=n, nodiag=T))

  tree = list()
  #nodes = u  +  n  +  2*nchoosek(n,2) # u inputs, n nodes and n over 2 edges
  nodes = u  +  n  +  n*n
    
  for( i in 1:nodes )
  {
    tree[[i]] = 0
    
    if (i <= u) 
    {
      tree[[i]] = NA
      next
    }
    else if (i > u & i <= (u+n))
    {
      k = i - u
      
      #C matrix
      tree[[i]] = which(C[k,]==1)
      
      #A matrix
      a = which(A[k,]==1)
      tree[[i]] = c(tree[[i]], ((u+n)+(a*n-n)+k))
    }    
    else if ( i > (u+n) )
    {
      k = i - (u+n)
      
      #B matrix
      if( B1[k] ) tree[[i]] = c(tree[[i]], 1)
      if( B2[k] ) tree[[i]] = c(tree[[i]], 2)
      if( B3[k] ) tree[[i]] = c(tree[[i]], 3)
      
      #A matrix
      
      if( A[k] )
      {
        if( k%%n == 0 )  tree[[i]] = c(tree[[i]], floor(k/n) + n)
        else             tree[[i]] = c(tree[[i]], floor(k/n) + 1 + n)
      }
      
      if ( length(tree[[i]]) > 1 ) tree[[i]] = tree[[i]][-1]
      else                         tree[[i]] = NA
    }
    
  }
  
  return(tree)

}

rdcm.ms.create.ts.init = function(DCMe)
{
  nu  = DCMe@M[[1]]@m
  nn  = DCMe@M[[1]]@l
  #nts = nu + nn + 2*nchoosek(nn, 2)
  nts = nu + nn + nn*nn
  ts  = array(0, dim=c(DCMe@M[[1]]@ns, nts))
  
  for( i in 1:nu )
  {
    ts[,i] = rdcm.ms.resample.input2bold( u=convolve.hrf(DCMe@U@u[,i], double.gamma.hrf(TR=DCMe@M[[1]]@Ydt, microtime=dim(DCMe@U@u)[1]/dim(DCMe@Y@y)[1])), 
                                          y=DCMe@Y@y[,i], 
                                          TR=DCe@M[[1]]@Ydt)
  }
  
  ts[,(1+nu):(nu+nn)] = DCMe@Y@y
  for( i in 1:nn )
  {
    ts[,(nu+nn+seq(1,nn*nn,nn)+(i-1))] = DCMe@Y@y
  }
  
  return( ts )
}

rdcm.ms.create.ts = function(tree, ts, input.scaling=0.1, u=rdcm.ms.default.inputs, n=rdcm.ms.default.nodecount)
{
  intermediates = (u+n+1):(u+n+n*n)
  
  for( i in intermediates )
  {
    modulators = which( tree[[i]] %in% c(1,2,3) )
    if( length(modulators) > 0 )
    {
      for( m in modulators )
      {
        ts[,i] = ts[,i] + input.scaling * ts[,tree[[i]][m]]
      }
    }
  }
  
  return( ts )
}

gamma.pdf = function(vals, mu, var)
{
  res = array(0, length(vals))
  if( mu > 0 & var > 0.00001 )
  {
    a = (mu^2) / var
    b = mu / var
    c = lgamma(a)
    if( abs(c) < 150 )
    {
      for( i in 1:length(res) )
      {
        if( vals[i] > 0.000001 )
        {
          res[i] = exp(a * log(b) + (a-1) * log(vals[i]) - b * vals[i] - c)
        }
      }
    }
  }
  #return( x^(a-1) * exp(-x) / Gamma(a) )
  return( res )
}

gamma.pdf.fsl = function(npts, mult, delay, sigma)
{
  grot = seq(0, npts-1, 1) / mult
  
  grot = gamma.pdf( grot, delay, sigma*sigma )
  
  return(grot)
}

double.gamma.hrf = function(TR=3.22, microtime=16, sigma1=2.449, delay1=6, sigma2=4, delay2=16, ratio=6)
{
  DT = TR/microtime
  mult = 1/DT
  
  fw = (delay2 + sigma2*5) * mult
  
  dg = gamma.pdf.fsl(fw, mult, delay1, sigma1) - gamma.pdf.fsl(fw, mult, delay2, sigma2)/ratio
  
  return(dg)
}

convolve.hrf = function(u, kernel)
{
  length(kernel) = length(u)
  kernel[which(is.na(kernel))] = 0
  kernel = rev(kernel)
  
  return( convolve(u, kernel) )  
}

rdcm.ms.resample.input2bold = function( u, y, TR=3.22 )
{
  dt = (length(u) / length(y))
  ru = interp1(seq(0,(length(u)-1),1), u, seq(0,(length(u)-1),dt))
  
  return( ru - (abs(max(ru)) - abs(min(ru))) / 2 )
  #return( ru )
}

# Interact input with BOLD curve
#   1. create HRF in input time resolution (TR/microtime_bins)
#   2. convolve input with HRF kernel
#   3. resample convolved input to BOLD time resolution (TR)

rdcm.ms.unite.score = function(csvfile)
{
  df = rdcm.ms.data.prepare(csvfile)
  
  if ( ! ("Fe" %in% colnames(df)) )
    stop("Error: no Fe in data.frame")
  if ( ! ("dH" %in% colnames(df)) )
    stop("Error: no dH in data.frame")
  
  dFe = max(df$Fe) - df$Fe; dFe = dFe / max(dFe)
  dH = df$dH / max(df$dH)
  i = which(dFe == min(dFe))
  Score = 1 - sqrt( (dFe[i] - dFe)^2 + (dH[i] - dH)^2 )
  df = data.frame(df, Score)
  
  return(df)
}


library('mclust')
library('cowplot')
library('scales')
rdcm.ms.classify.dFe = function(csvfile, msga=NULL, nsample=NULL, ref.mID = NULL)
{

  df = rdcm.ms.data.prepare(csvfile, isol=TRUE)
  
  if (!is.null(ref.mID))
  {
    df$dFe = df$Fe[df$mID == ref.mID] - df$Fe
    dFe.limits = c(min(df$dFe), quantile(df$dFe, 0.97))
  }
  else
  {
    dFe.limits = c(0, 500)
  }
  
  
  if (!is.null(nsample) && dim(df)[1] >= nsample)
  {
    ns = runif(nsample, 1, dim(df)[1])
    df = df[ns, ]
  }
  
  if ( !is.null(msga) )
  {
    msga = read.table(msga, header=TRUE, sep=',', stringsAsFactors=FALSE)
    models = adply(1:max(msga$run), 1, function(x){
      l = tail(msga[which(msga$run == x),],1);
      colnames(l)[c(4,5)] = c('dFe', 'dH');
      l[,'dFe'] = max(csvfile$Fe) - l[,'dFe'];
      return (l)
      })
  }
  else
  {
    models = data.frame(name = c('Suggested', 'Best', 'Best.BMR', 'Search', 'Full'), dH = c(10, 0.1, 6, 8, 8), dFe = c(258.1, 3.0, 197.62, 29.56, 478.1))
    #models = data.frame(name = c('Suggested', 'Best', 'Best.BMR', 'Search', 'Full'), dH = c(14, 6, 0.1, 6, 6), dFe = c(175.5, 44.94, 3.0, 21.45, 6.57))
  }
  
  if ( ! ("dFe.mclust" %in% colnames(df)) )
  {
    dFe_mclust = densityMclust(df$dFe)
    df = cbind(df, dFe_mclust$classification)
    colnames(df)[dim(df)[2]] = 'dFe.mclust'
    df$dFe.mclust = as.factor(df$dFe.mclust)
    df$wgth = count(df$dFe.mclust)[df$dFe.mclust,2] / count(df$dFe.mclust)[,2]
  }  
  
  margin.density = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute, fill = cluster)) +
      geom_density(aes(weight=wgth), alpha = 0.2, adjust=2) +
      #scale_colour_branded(other = "yellow") + 
      #scale_y_continuous(labels=percent) +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin())
    if ( attribute == 'dFe' ) 
      g = g + scale_x_continuous(expand = c(0,0), limits = dFe.limits) + geom_histogram(aes(weight = 0.6), alpha=0.2, bins = 100)
    return(g)
  }
  margin.hist = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute, color = cluster, fill = cluster)) +
      geom_histogram(alpha=0.2, position="identity") +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin())
    
    return(g)
  }
  margin.hist2 = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute)) +
      geom_histogram() +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin()) 
    return(g)
  }
  
  main.density2d = ggplot(df, aes(x=dH, y = dFe)) + #, color = dFe.mclust, fill = dFe.mclust)) +
    #stat_density_2d(aes(alpha= ..level.., fill= ..level..), geom='polygon', bins=200) +
    #scale_fill_gradient(low = "red", high = "yellow") +
    stat_density_2d(aes(fill= ..density..), geom='raster', contour=FALSE, n=100, h=c(2.5, 40)) +
    scale_fill_distiller(palette= "Spectral", direction=-1) +
    scale_x_continuous(expand=c(0,0), limits=c(0, 18), breaks=c(0, 2, 4, 6, 8, 10, 12, 14, 16, 18)) +
    scale_y_continuous(expand=c(0,0), limits=dFe.limits, breaks=c(0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000)) +
    guides(color = FALSE, alpha = FALSE, fill=FALSE) +
    xlab(label="Hd") +
    theme(plot.margin = margin())
  main.density2d.mod = main.density2d +
    geom_point(data=models, aes(x=dH, y = dFe), label=names)# + geom_text(data=models, x=models$dH, y=models$dFe, label=models$name, size=3, hjust=-0.15, vjust=-0.2)
    #geom_point(data=models, aes(x=dH, y = dFe), size = 1)
  main.scatter = ggplot(df, aes(x=dH, y = dFe, color = dFe.mclust)) +
    geom_point(position='jitter') +
    scale_x_continuous(expand=c(0,0), limits=c(0, 18), breaks=c(0, 2, 4, 6, 8, 10, 12, 14, 16, 18)) +
    scale_y_continuous(expand=c(0,0), limits=c(0, 1100), breaks=c(0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000)) +
    guides(color = FALSE, alpha = FALSE) +
    xlab(label="Hd") +
    theme(plot.margin = margin())
  
  main.plot = main.density2d
  margin.x = margin.density(df, "dH", "dFe.mclust")
  margin.y = margin.density(df, "dFe", "dFe.mclust") + coord_flip()
  margin.x.aligned = align_plots(margin.x, main.plot, align='v')[[1]]
  margin.y.aligned = align_plots(margin.y, main.plot, align='h')[[1]]
  
  full.plot = plot_grid(
    margin.x.aligned
    , NULL
    , main.plot
    , margin.y.aligned
    , ncol = 2
    , nrow = 2
    , rel_heights = c(0.3, 1)
    , rel_widths = c(1, 0.4)
  )
  
  full.plot
  
  ggsave('/mnt/raid6_data/user/aranyics/modelspace/graphics/rdcm_ms_cowplot4.pdf', width=6, height=5)
  
  main.plot = main.density2d.mod
  full.plot = plot_grid(
    margin.x.aligned
    , NULL
    , main.plot
    , margin.y.aligned
    , ncol = 2
    , nrow = 2
    , rel_heights = c(0.3, 1)
    , rel_widths = c(1, 0.4)
  )
  
  full.plot
  
  ggsave('/mnt/raid6_data/user/aranyics/modelspace/graphics/rdcm_ms_cowplot4_mod.pdf', width=6, height=5)
  
  return( full.plot )
}

branded_colors <- list(
  "blue"   = "#00798c",
  "red"    = "#d1495b",
  "yellow" = "#edae49",
  "green"  = "#66a182",
  "navy"   = "#2e4057", 
  "grey"   = "#8d96a3"
)

branded_pal <- function(
  primary = "blue", 
  other = "grey", 
  direction = 1
) {
  stopifnot(primary %in% names(branded_colors))
  
  function(n) {
    if (n > 6) warning("Branded Color Palette only has 6 colors.")
    
    if (n == 2) {
      other <- if (!other %in% names(branded_colors)) {
        other
      } else {
        branded_colors[other]
      }
      color_list <- c(other, branded_colors[primary])
    } else {
      color_list <- branded_colors[1:n]
    }
    
    color_list <- unname(unlist(color_list))
    if (direction >= 0) color_list else rev(color_list)
  }
}

scale_colour_branded <- function(
  primary = "blue", 
  other = "grey", 
  direction = 1, 
  ...
) {
  ggplot2::discrete_scale(
    "colour", "branded", 
    branded_pal(primary, other, direction), 
    ...
  )
}
