First: run ReDCM.make.database() function in ReDCM_modelsearch_utils.r
