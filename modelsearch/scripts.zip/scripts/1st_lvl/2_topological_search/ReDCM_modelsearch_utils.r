require('stringr')


ReDCM.get.files = function(subject, projdir)
{
  Amx = paste0(projdir, '/data/A.csv')
  Bmx = paste0(projdir, '/data/B.csv')
  ms  = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/dcm_ms/fullspace_dcm.csv')
  ms.bmr  = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/bmr_ms/fullspace_bmr.csv')
  
  return (list(Amx=Amx, Bmx=Bmx, ms=ms, ms.bmr=ms.bmr))
}


ReDCM.make.database = function(projdir, subject, force=FALSE, bmr.ms = FALSE)
{
  
  if (bmr.ms)
  {
    info.bmr.file = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/bmr_ms/fullspace_bmr_info.csv')
    par.bmr.file  = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/bmr_ms/fullspace_bmr_par.csv')
    if (!force)
    {
      if (file.exists(info.bmr.file))
      {
        info = read.table(info.bmr.file, header = TRUE, sep = ',', stringsAsFactors = FALSE)
        
        if (file.exists(par.bmr.file))
        {
          pars = read.table(par.bmr.file, header = TRUE, sep = ',', stringsAsFactors = FALSE)
          
          return( list(info=info, par=pars) )
        }
      }
      else
      {
        force = TRUE
      }
    }
  }
  
  info.file = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/dcm_ms/fullspace_dcm_info.csv')
  par.file  = paste0(projdir, '/results/modelspace/vdmodel_4node_', subject, '/dcm_ms/fullspace_dcm_par.csv')
  if (!force)
  {
    if (file.exists(info.file))
    {
      info = read.table(info.file, header = TRUE, sep = ',', stringsAsFactors = FALSE)
  
      if (file.exists(par.file))
      {
        pars = read.table(par.file, header = TRUE, sep = ',', stringsAsFactors = FALSE)
        
        return( list(info=info, par=pars) )
      }
    }
  }
  
  files = ReDCM.get.files(subject, projdir)
  df = read.table(files$ms, header = TRUE, sep = ',', stringsAsFactors = FALSE)
  df = df[order(df$ID),] #df should be ordered by increasing ID as Amx and Bmx are ordered
  Amx = read.table(files$Amx, sep = ',', header = FALSE, colClasses = "character", stringsAsFactors = FALSE)
  Bmx = read.table(files$Bmx, sep = ',', header = FALSE, colClasses = "character", stringsAsFactors = FALSE)
  
  maxi = which(df$Fe == max(df$Fe))[1]
  cat('calculating Hamming-distance...\n')
  dHD = apply(array(1:dim(df)[1]), 1, function(x){ ReDCM.hamming.distance.bitvect(paste0(Amx[maxi,1], Bmx[maxi,1]),
                                                                                  paste0(Amx[x,1],    Bmx[x,1])) })
  
  info = data.frame(ID=df$ID, mID=df$mID, A=as.numeric(df$A), B1=as.numeric(df$B1), B2=as.numeric(df$B2), B3=as.numeric(df$B3),
                    Fe=df$Fe, dFe=df$Fe-df$Fe[maxi], dHD=dHD,
                    bitvector=paste0('b', Amx[,1], Bmx[,1]), stringsAsFactors = FALSE)
  write.table(info, info.file, sep = ',', col.names = TRUE, row.names = FALSE)
  
  pars = df[,c(1, 2, which(grepl("^p", colnames(df))))] #assuming first column is ID
  write.table(pars, par.file, sep = ',', col.names = TRUE, row.names = FALSE)
  
  if (bmr.ms)
  {
    df.bmr = read.table(files$ms.bmr, header = FALSE, sep = ',', stringsAsFactors = FALSE)
    df.bmr = df.bmr[,-dim(df.bmr)[2]]
    colnames(df.bmr) = colnames(df)[-c(1,2)]
    cat('reordering BMR modelspace...\n')
    bmr.order = apply(df, 1, function(x){which(x[3]==df.bmr$A & x[5]==df.bmr$B2 & x[6]==df.bmr$B3)}) #B1 is always 0
    df.bmr = df.bmr[bmr.order,]
    df.bmr = cbind(ID=df$ID, mID=df$mID, df.bmr)
    df.bmr[,-c(1,7)] = round(df.bmr[,-c(1,7)], 4)
    
    maxi = which(df.bmr$Fe == max(df.bmr$Fe))[1]
    cat('calculating Hamming-distance for bmr...\n')
    dHD = apply(array(1:dim(df.bmr)[1]), 1, function(x){ ReDCM.hamming.distance.bitvect(paste0(Amx[maxi,1], Bmx[maxi,1]),
                                                                                    paste0(Amx[x,1],    Bmx[x,1])) })
    
    info.bmr = data.frame(ID=df.bmr$ID, mID=df.bmr$mID, A=as.numeric(df.bmr$A), B1=as.numeric(df.bmr$B1), B2=as.numeric(df.bmr$B2), B3=as.numeric(df.bmr$B3),
                      Fe=df.bmr$Fe, dFe=df.bmr$Fe-df.bmr$Fe[maxi], dHD=dHD,
                      bitvector=info$bitvector, stringsAsFactors = FALSE)
    write.table(info.bmr, info.bmr.file, sep = ',', col.names = TRUE, row.names = FALSE)
    
    pars.bmr = df.bmr[,c(1, 2, which(grepl("^p", colnames(df.bmr))))] #assuming first column is ID
    cat("correcting parameter values with bitmask...\n")
    bv = ReDCM.id.to.bitvector.multiple(pars.bmr$ID, info.bmr)
    pars.bmr[,-c(1,2)] = pars.bmr[,-c(1,2)] * bv
    write.table(pars.bmr, par.bmr.file, sep = ',', col.names = TRUE, row.names = FALSE)
    
    return(list(info=info.bmr, par=pars.bmr))
  }
  
  return(list(info=info, par=pars))
}


ReDCM.make.bitmask = function( info )
{
  info = subset(info, as.numeric(mID) == max(mID)) #the most full matrix is almost the mask
  
  nB = length( which(which(grepl("^B", colnames(info))) < which(colnames(info) == "Fe")) )
  n  = length( strsplit(info$bitvector, '')[[1]][-1] ) / (nB+1) #first item is character 'b'
  
  Amask = c(as.integer(strsplit(info$bitvector, '')[[1]][-1])[1:n] - diag(sqrt(n)))
  Bmask = as.integer(strsplit(info$bitvector, '')[[1]][-1])[(n+1):(n+nB*n)]
  
  return( list(A=Amask, B=Bmask) )
}


ReDCM.make.bitvectors = function( info )
{
  bitvectors = sapply(info$bitvector, function(x){as.integer(strsplit(x, '')[[1]][-1])})
  colnames(bitvectors) = NULL
  
  return( t(bitvectors) )
}


ReDCM.get.HD1 = function( bitvect, bitmask, mode='none' )
{
  mask = c(bitmask$A, bitmask$B)
  
  models = NULL
  for (b in which(mask == 1))
  {
    tmp = bitvect
    if (mode == 'fw')
    {
      if (tmp[b]==1) next
    }
    else if (mode == 'bw')
    {
      if (tmp[b]==0) next
    }
    tmp[b] = 1 - tmp[b]
    models = rbind(models, tmp)
  }
  rownames(models) = NULL
  
  return(models)
}


ReDCM.hamming.distance.bitvect = function( b1, b2 )
{
  return (sum( (as.numeric(strsplit(b1,'')[[1]]) != as.numeric(strsplit(b2,'')[[1]])) * 1 ))
}


ReDCM.contains.bitvect = function( bitvect, used.bitvect )
{
  contains = FALSE
  if (is.null(used.bitvect))
    return( FALSE )
  if (class(used.bitvect) != "matrix")
  {
    used.bitvect = t(matrix(used.bitvect))
  }
  
  return( any( apply(used.bitvect, 1, function(x){ all(x == bitvect) }) ) )
}


ReDCM.isvalid.bitvect = function( bitvect, bitmask )
{
  #TODO to implement
  #it is always valid in test model
  return ( TRUE)
}


ReDCM.bitvector.to.id = function( b, bitvectors )
{
  return( which( apply(bitvectors, 1, function(x){all( b == x )}) ) )
}


ReDCM.id.to.bitvector = function( id, modelspace )
{
  return( as.integer(strsplit(subset(modelspace, ID == id)$bitvector, '')[[1]][-1]) )
}


ReDCM.bitvector.to.id.multiple = function( bb, bitvectors )
{
  if (class(bb) == "numeric" || class(bb) == "integer")
    bb = t(matrix(bb))
  if (is.null(bitvectors))
    return (bb)
  return( apply( bb, 1, function(b){ ReDCM.bitvector.to.id(b, bitvectors) } ) )
}


ReDCM.id.to.bitvector.multiple = function( ids, modelspace )
{
  return( t( sapply( array(ids), function(id) { ReDCM.id.to.bitvector(id, modelspace) } ) ) )
}


ReDCM.duplicate.bitvectors = function( bb )
{
  if (class(bb) != "matrix")
    return (bb)
  if (dim(bb)[1] == 1)
    return (bb)
  duplicates = NULL
  for (i in 1:(dim(bb)[1]-1))
    for (j in (i+1):dim(bb)[1])
    {
      if ( all(bb[i,] == bb[j,]) )
      {
        duplicates = c(duplicates, j)
      }
    }
  return (duplicates)
}


