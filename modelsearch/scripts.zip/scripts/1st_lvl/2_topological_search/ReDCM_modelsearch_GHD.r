ReDCM_modelsearch_GHD_init = function( modelspace )
{
  #return( ReDCM.id.to.bitvector( modelspace$ID[which(modelspace$mID == max(modelspace$mID))], modelspace ) )
  #return( ReDCM.id.to.bitvector( modelspace$ID[which(modelspace$mID == min(modelspace$mID))], modelspace ) )
  return( ReDCM.id.to.bitvector( sample(modelspace$ID, 1), modelspace ) )
}


ReDCM_modelsearch_GHD_generate_population = function( M, bitmask )
{
  #assumes GHF population generation start with a single bitvector in M
  return( rbind( M, ReDCM.get.HD1( M, bitmask ) ) )
}


ReDCM_modelsearch_GHD_alter_population = function( M, estimated, modelspace, bitvectors, bitmask, params, p0=0.9 )
{
  if (is.null(estimated))
    return( M )
  
  idx = which(c(bitmask$A, bitmask$B) == 1)
  
  params = params[which(params$ID %in% ReDCM.bitvector.to.id.multiple( estimated, bitvectors )),(idx + 2)] # +2 for columns ID and mID
  is.na(params) <- params == 0
  pmeans = colMeans(params, na.rm = TRUE)
  
  M[,idx[which(pmeans > p0)]] = 1
  
  d = ReDCM.duplicate.bitvectors( M )
  if (!is.null(d))
    M = M[-d,]
  
  return (M)
}
