ReDCM_modelsearch_GA_init = function( modelspace, bitmask, k )
{
  M0 = ReDCM.id.to.bitvector( modelspace$ID[sample(1:dim(modelspace)[1], 1)], modelspace )
  M = M0
  for (i in 2:k)
  {
    generate = TRUE
    while (generate)
    {
      tmp = ReDCM_modelsearch_GA_mutate( M0, bitmask, c(8,8), 1.0 )
      if ( !ReDCM.contains.bitvect(tmp, M) )
      {
        generate = FALSE
      }
    }
    M = rbind(M, tmp)
  }
  rownames(M) = NULL
  
  return(M)
}


ReDCM_modelsearch_GA_generate_population = function( M, modelspace, bitmask, estimated )
{
  n = dim(M)[1]
  
  # crossover phase
  for (i in 1:(n-1))
  {
    for (j in (i+1):n)
    {
      available = FALSE
      k = 0
      while (!available)
      {
        if (k > 100)
        {
          tmp = ReDCM_modelsearch_GA_mutate( M[i,], bitmask, c(2,8), 0.5 )
        }
        if (k > 110)
        {
          #timed out
          break
        }
        
        tmp = ReDCM_modelsearch_GA_crossover( M[i,], M[j,], bitmask )
        
        k = k + 1
        
        if ( ReDCM.contains.bitvect( tmp, estimated ) )
          next
        if ( !ReDCM.isvalid.bitvect( tmp, bitmask) )
          next
        
        M = rbind(M, tmp)
        available = TRUE
      }
    }
  }
  
  # mutation phase
  for (i in 1:dim(M)[1])
  {
    available = FALSE
    k = 0
    while (!available)
    {
      if (k > 100)
      {
        #timed out
        break
      }
      
      tmp = ReDCM_modelsearch_GA_mutate( M[i,], bitmask, c(2,8), 0.5 )
      
      k = k + 1
      
      if ( ReDCM.contains.bitvect( tmp, estimated ) )
        next
      if ( !ReDCM.isvalid.bitvect( tmp, bitmask) )
        next
      
      M = rbind(M, tmp)
      available = TRUE
    }
  }
  rownames(M) = NULL
  
  return (M)
}


ReDCM_modelsearch_GA_alter_population = function( M, estimated, modelspace, bitvectors, bitmask, params, p0=0.9, p1=0.3 )
{
  if (is.null(estimated))
    return( M )
  
  idx = which(c(bitmask$A, bitmask$B) == 1)
  
  params = params[which(params$ID %in% ReDCM.bitvector.to.id.multiple( estimated, bitvectors )),(idx + 2)] # +2 for columns ID and mID
  is.na(params) <- params == 0
  pmeans = colMeans(params, na.rm = TRUE)
  
  M[,idx[which(pmeans > p0)]] = 1
  M[,idx[which(pmeans < p1)]] = 0
  
  d = ReDCM.duplicate.bitvectors( M )
  if (!is.null(d))
    M = M[-d,]
  
  return (M)
}


ReDCM_modelsearch_GA_crossover = function( bv1, bv2, bitmask )
{
  idx = which( c(bitmask$A, bitmask$B) == 1 )
  cp = idx[sample( 1:length(idx), 2, replace = TRUE)]
  #while ( all(bv1[min(cp):max(cp)] == bv2[min(cp):max(cp)]) )
  #  cp = idx[sample( 1:length(idx), 2, replace = TRUE)]
  
  bv1[min(cp):max(cp)] = bv2[min(cp):max(cp)]
  
  #cat(paste(cp, sep = ' ', collapse = ' '))
  #cat('\n')
  
  return (bv1)
}


ReDCM_modelsearch_GA_mutate = function( bitvector, bitmask, nrange, p0 )
{
  idx = which( c(bitmask$A, bitmask$B) == 1 )
  ntochange = sample(nrange[1]:nrange[2], 1, replace = FALSE)
  tochange = sort(sample(idx, ntochange, replace = FALSE))
  ptochange = integer()
  while (length(ptochange) < 1)
    ptochange = tochange[ which((p0 - runif(ntochange)) > 0.0) ]
  
  bitvector[ptochange] = 1 - bitvector[ptochange]
  
  return (bitvector)
}
