


msdir = '~/research/modelsearch/results/modelspace/'
subjects = unlist(lapply( strsplit(dir(msdir, pattern = 'vdmodel_4node'), '_'), function(x){x[3]} ))
projdir = '~/research/modelsearch/'
outdir = '~/research/modelsearch/results/BMR_modelsearch/'
dir.create(outdir, showWarnings = FALSE)

source(paste0(projdir, 'scripts/1st_lvl/2_topological_search/ReDCM_modelsearch.r'))

# 1. Run modelsearch 20 times for every subjects and every method

# r = 20
# bmr.ms = TRUE
# 
# #Computations
# for (s in subjects)
# {
#   for (m in c('GA', 'GES', 'GHD'))
#   {
#     for (p in c(TRUE, FALSE))
#     {
#       fn = paste0(outdir, paste(s,m,p*1,r,sep = '_'), '.Rdata')
#       fn.csv = paste0(outdir, paste(s,m,p*1,r,sep = '_'), '.csv')
#       ms = ReDCM.modelsearch(projdir, s, m, p, bmr.ms, r)
#       #save(ms, file = fn)
#       result = data.frame(data = 'Q', subject = s, method = m, p.check = p*1, ms$report, stringsAsFactors = FALSE)
#       result$data[(dim(result)[1]-(r-1)):dim(result)[1]] = 'S'
#       write.table(result, fn.csv, sep = ',', col.names = TRUE, row.names = FALSE)
#     }
#   }
# }


# # 2 Some figures
# TODO!!! normalize S results by modelspace range
# S = NULL
# for (f in dir(outdir, pattern = '20.csv', full.names = TRUE))
# {
#   tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
#   S = rbind(S, subset(tmp, data=='S'))
# }
# 
# gg = ggplot(S, aes(method, dFe, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
# gg = ggplot(S, aes(method, dH, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
# gg = ggplot(S, aes(method, calc, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
# 
# 
# gg = ggplot(s01.ms, aes(method, dH)) + geom_boxplot() + geom_jitter(position=position_jitter(0.2)) + facet_grid(.~p.check)
# gg = ggplot(s01.ms, aes(method, calc)) + geom_boxplot() + geom_jitter(position=position_jitter(0.2)) + facet_grid(.~p.check)




# 3. Summary tables for modelsearch

myMedian = function(data)
{
  return( sort(data)[ floor(length(data)/2) + 1 ] )
}

S.dcm = NULL
for (f in dir('~/research/modelsearch/results/DCM_modelsearch/', pattern = '20.csv', full.names = TRUE))
{
  tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
  S.dcm = rbind(S.dcm, subset(tmp, data=='S'))
}

S.bmr = NULL
for (f in dir('~/research/modelsearch/results/BMR_modelsearch/', pattern = '20.csv', full.names = TRUE))
{
  tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
  S.bmr = rbind(S.bmr, subset(tmp, data=='S'))
}


methods = c('GES', 'GHD', 'GA', 'post hoc')
p.check = c(0, 1)
subjects = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')
PLUS.POSTHOC.MODELS = c(60414, 65264, 61142, 63178, 63486, 48918, 64000, 65504, 52879, 59842)
for (s in 1:length(subjects))
{
  cat(subjects[s], ' ')
  db = ReDCM.make.database('~/research/modelsearch/', subjects[s])
  m = db$info[which(db$info$ID == PLUS.POSTHOC.MODELS[s]),]
  PLUS.POSTHOC.DF = data.frame(data="S", subject=subjects[s], method="post hoc", p.check=0, run=1, iter=1, model=PLUS.POSTHOC.MODELS[s], Fe=m$Fe, dFe=m$dFe, dH=m$dH, calc=0)
  S.dcm = rbind(S.dcm, PLUS.POSTHOC.DF)
  db = ReDCM.make.database('~/research/modelsearch/', subjects[s], bmr.ms = TRUE)
  m = db$info[which(db$info$ID == PLUS.POSTHOC.MODELS[s]),]
  PLUS.POSTHOC.DF = data.frame(data="S", subject=subjects[s], method="post hoc", p.check=0, run=1, iter=1, model=PLUS.POSTHOC.MODELS[s], Fe=m$Fe, dFe=m$dFe, dH=m$dH, calc=0)
  S.bmr = rbind(S.bmr, PLUS.POSTHOC.DF)
}

SS = NULL
for(p in p.check)
{
  for(m in methods)
  {
    for (s in subjects)
    {
      # tmp.dcm = S.dcm[which(S.dcm$subject == s & S.dcm$method == m & S.dcm$p.check ==p),]
      # tmp.bmr = S.bmr[which(S.bmr$subject == s & S.bmr$method == m & S.bmr$p.check ==p),]
      # sel.dcm = which(tmp.dcm$dFe == myMedian(tmp.dcm$dFe))[1]
      # sel.bmr = which(tmp.bmr$dFe == myMedian(tmp.bmr$dFe))[1]
      # SS = rbind(SS, data.frame(
      #   s, m, p,
      #   tmp.dcm$model[sel.dcm],
      #   myMedian(tmp.dcm$dFe), sd(tmp.dcm$dFe),
      #   myMedian(tmp.dcm$dH), sd(tmp.dcm$dH),
      #   mean(tmp.dcm$calc),
      #   tmp.bmr$model[sel.bmr],
      #   myMedian(tmp.bmr$dFe), sd(tmp.bmr$dFe),
      #   myMedian(tmp.bmr$dH), sd(tmp.bmr$dH),
      #   mean(tmp.bmr$calc)
      # ))
    }
    tmp.dcm = S.dcm[which(S.dcm$method == m & S.dcm$p.check ==p),]
    tmp.bmr = S.bmr[which(S.bmr$method == m & S.bmr$p.check ==p),]
    sel.dcm = which(tmp.dcm$dFe == myMedian(tmp.dcm$dFe))[1]
    sel.bmr = which(tmp.bmr$dFe == myMedian(tmp.bmr$dFe))[1]
    SS = rbind(SS, data.frame(
      'average', m, p,
      0,
      mean(tmp.dcm$dFe), sd(tmp.dcm$dFe),
      mean(tmp.dcm$dH), sd(tmp.dcm$dH),
      mean(tmp.dcm$calc),
      0,
      mean(tmp.bmr$dFe), sd(tmp.bmr$dFe),
      mean(tmp.bmr$dH), sd(tmp.bmr$dH),
      mean(tmp.bmr$calc)
    ))
  }
}


