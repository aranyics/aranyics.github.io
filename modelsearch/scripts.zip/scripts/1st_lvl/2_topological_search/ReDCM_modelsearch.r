
suppressPackageStartupMessages( library("ReDCM") )

#source( paste0(dirname(thisFile()), 'ReDCM_modelsearch.r') )
#source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_utils.r') )
#source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GES.r') )
#source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GHD.r') )
#source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GA.r') )
scriptdir = '~/research/modelsearch/scripts/1st_lvl/2_topological_search/'
source( paste0(scriptdir, 'ReDCM_modelsearch_utils.r') )
source( paste0(scriptdir, 'ReDCM_modelsearch_GES.r') )
source( paste0(scriptdir, 'ReDCM_modelsearch_GHD.r') )
source( paste0(scriptdir, 'ReDCM_modelsearch_GA.r') )


ReDCM.modelsearch = function(datadir, subject, method, check.params=FALSE, bmr.ms=FALSE, run=1)
{
  
  database = ReDCM.make.database(datadir, subject, bmr.ms = bmr.ms)
  bitmask  = ReDCM.make.bitmask(database$info)
  modelspace = database$info
  params     = database$par
  bitvectors = ReDCM.make.bitvectors(modelspace)
  
  Q = NULL
  
  if (method != 'GA')
  {
    #run = 1
    run = run
  }
  
  for (r in 1:run)
  {
    cat(r, '\n')
    #print.data.frame( tail(Q, 1) )
    
    M = ReDCM.modelsearch.initialize(modelspace, bitmask, method)
    Mbest = M
    estimated = NULL
    
    minima = 0
    dminima = 0
    iter = 0
    while (TRUE)
    {
      iter = iter + 1
      if (iter > 40) break
      cat(iter, ' ')
      
      #1. generate, check inconsistency and replace already used models
      M = ReDCM.modelsearch.generate.population(M, modelspace, bitmask, estimated, method, minima)
      if (is.null(M)) break
      if (method == 'GES' || method =='GHD')
        #if ( iter > 1 && length(c(M)) == length(c(Mbest)) )
        #  break
      if (method == 'GES' && dminima > 1)
        break
      
      #2. alter modelspace (reduce or replace) based on parameter check
      if ( check.params )
      {
        #this may alter search trajectory
        M = ReDCM.modelsearch.alter.population( M, estimated, modelspace, bitvectors, bitmask, params, method)
        if (length(M)/64 <= 1)
          break
      }
      cat(' ', length(M)/64, ' ')
      
      #3. filter already estimated models
      M = ReDCM.filter.estimated.models(M, estimated, modelspace, bitvectors, method)
      
      #4. replaces DCM estimations with modelspace lookups
      E = ReDCM.modelsearch.lookup(M, bitvectors, modelspace)
      estimated = rbind(estimated, M)
      
      #5. find best model of the selected population
      M1 = ReDCM.modelsearch.BMS.ffx(E, modelspace, method)
      if (is.null(M1))
        M1 = Mbest
      
      #6. generate report every iteration
      Q = ReDCM.modelsearch.report(E, M, Q, method, r, iter)
      #print.data.frame( tail(Q, 1) )
      
      #7. update ending criteria
      minima.new = ReDCM.modelsearch.convergence(Mbest, M1, modelspace, bitvectors, method, minima, iter)
      cat(minima.new)
      M = M1
      if (method == 'GA')
        Mbest = M1
      if (minima.new <= minima)
        Mbest = M1
      if (minima.new > minima)
        dminima = dminima+1
      else
        dminima = 0
      minima = minima.new
      cat('\n')
    }
    
  }
  
  S = ReDCM.modelsearch.summary(Q) #summarize modelsearch report over subsequent runs
  
  #cat('\n')
  #print.data.frame(rbind(Q, S))
  
  return(list(report=rbind(Q, S), models=Mbest))

}


ReDCM.modelsearch.initialize = function(modelspace, bitmask, method)
{
  
  if (method == 'GES')
  {
    M = ReDCM_modelsearch_GES_init( modelspace )
  }
  if (method == 'GHD')
  {
    M = ReDCM_modelsearch_GHD_init( modelspace )
  }
  if (method == 'GA')
  {
    M = ReDCM_modelsearch_GA_init( modelspace, bitmask, 4 )
  }
  
  return (M)
  
}


ReDCM.modelsearch.generate.population = function(M, modelspace, bitmask, estimated, method, minima)
{  
  if (method == 'GES')
  {
    #if (minima <= 1)
    if (TRUE)
      M = ReDCM_modelsearch_GES_generate_population(M, bitmask, fw=1-(minima%%2))
    else
      return (NULL)
  }
  if (method == 'GHD')
  {
    if (minima == 0)
      M = ReDCM_modelsearch_GHD_generate_population(M, bitmask)
    else
      return (NULL)
  }
  if (method == 'GA')
  {
    if (minima <= 3)
      M = ReDCM_modelsearch_GA_generate_population(M, modelspace, bitmask, estimated)
    else
      return (NULL)
  }
  
  return (M)
}


ReDCM.modelsearch.alter.population = function( M, estimated, modelspace, bitvectors, bitmask, params, method)
{
  #return (M)
  
  if (method == 'GES')
  {
    M = ReDCM_modelsearch_GES_alter_population( M, estimated, modelspace, bitvectors, bitmask, params )
  }
  if (method == 'GHD')
  {
    M = ReDCM_modelsearch_GHD_alter_population( M, estimated, modelspace, bitvectors, bitmask, params )
  }
  if (method == 'GA')
  {
    M = ReDCM_modelsearch_GA_alter_population( M, estimated, modelspace, bitvectors, bitmask, params )
  }
  
  return (M)
}


ReDCM.filter.estimated.models = function( current, estimated, modelspace, bitvectors, method )
{
  if (is.null(estimated))
    return( current )
  ntop = 1
  if (method == 'GA')
    return( current ) # checks should have happened during population generation
    #ntop = 4
  if ( dim(current)[1] <= ntop )
    return( current )
  
  current.id = ReDCM.bitvector.to.id.multiple( current, bitvectors )
  top.current.id = current.id[1:ntop]
  current.id = current.id[-c(1:ntop)]
  estimated.id = ReDCM.bitvector.to.id.multiple( estimated, bitvectors )
  
  current.id = current.id[which( ! (current.id %in% estimated.id) )]
  if (length(current.id) == 0)
    return( ReDCM.id.to.bitvector.multiple( top.current.id, modelspace ) )
  
  return( rbind(ReDCM.id.to.bitvector.multiple( top.current.id, modelspace ),
                ReDCM.id.to.bitvector.multiple( current.id, modelspace )) )
}


ReDCM.modelsearch.lookup = function(M, bitvectors, modelspace)
{
  return( modelspace[ReDCM.bitvector.to.id.multiple( M, bitvectors ),] )
}


ReDCM.modelsearch.BMS.ffx = function(E, modelspace, method, ntop=1)
{
  Fe = E$Fe
  
  if (method == 'GA')
    ntop = 4
  ntop = min(dim(E)[1], ntop)
  if (ntop < 1)
    return (NULL)
  
  oi = order(Fe, decreasing=TRUE)[1:ntop]
  
  return ( ReDCM.id.to.bitvector.multiple(E$ID[oi], modelspace) )
}


ReDCM.modelsearch.report = function(E, M, Q, method, r, i, ntop=1)
{
  Fe = E$Fe
  dFe = E$dFe
  dH = E$dHD
  ID = E$ID
  
  if (method == 'GA')
    ntop = 4
  
  oi = order(Fe, decreasing=TRUE)[1:ntop]
  m0 = ID[ oi[1] ]
  f0 = Fe[ oi[1] ]
  d0 = dFe[ oi[1] ]
  h0 = dH[ oi[1] ]
  
  Q = rbind( Q, data.frame( run = r, iter = i, model = m0, Fe = f0, dFe = d0, dH = h0, calc = dim(M)[1] ) )
  
  return(Q)
}


ReDCM.modelsearch.convergence = function(M, M1, modelspace, bitvectors, method, minima, iter)
{
  if (iter == 1 && method == 'GA')
    return(0)
  
  M = modelspace[ReDCM.bitvector.to.id.multiple(M, bitvectors),]
  M1 = modelspace[ReDCM.bitvector.to.id.multiple(M1, bitvectors),]
  
  M.best = M[order(M$Fe, decreasing=TRUE)[1],]
  M1.best = M1[order(M1$Fe, decreasing=TRUE)[1],]
  
  m = mean(M$Fe)
  m1 = mean(M1$Fe)
  
  cat(max(m, m1), ' ')
  
  if (m > m1)
    return(minima+1)
  if (m == m1)
  {
    if (M.best$mID == M1.best$mID)
      return(minima+1)
    else
      return(minima)
  }
  
  if (method == 'GA')
    return(0)
  else if (method == 'GES' | method == 'GHD')
    return(minima)
}


ReDCM.modelsearch.summary = function( Q )
{
  S = NULL
  
  for ( r in unique(Q$run) )
  {
    tmp = subset( Q, run == r )
    S = rbind( S, data.frame(run = r, 
                             iter = max(tmp$iter), 
                             model = min(tmp$model), 
                             Fe = max(tmp$Fe), 
                             dFe = max(tmp$dFe),
                             dH = tmp$dH[which(tmp$Fe == max(tmp$Fe))][1], 
                             calc = sum(tmp$calc)  ) )
  }
  
  return( S )
}
