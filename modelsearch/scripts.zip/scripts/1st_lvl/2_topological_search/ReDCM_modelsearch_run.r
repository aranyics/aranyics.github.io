#!/usr/bin/env Rscript

args = commandArgs(trailingOnly = TRUE)

# test if there is at least one argument: if not, return an error
if (length(args) < 3) {
  stop("Specify (subject), (method) and (datadir) arguments. Datadir contains the data/ and results/ directories. Example:\n    Rscript ReDCM_modelsearch.r s01 GES /path/to/data", call.=FALSE)
}


## -----------------------------------------------------------------------------------------
## set environmental variables
.libPaths(rev(dir('~/R/x86_64-pc-linux-gnu-library', full.names=TRUE)))
cat( 'R package path: ' )
cat( .libPaths(), '\n', sep=':')

suppressPackageStartupMessages( library("ReDCM") )


thisFile <- function() {
  cmdArgs <- commandArgs(trailingOnly = FALSE)
  needle <- "--file="
  match <- grep(needle, cmdArgs)
  if (length(match) > 0) {
    # Rscript
    return(normalizePath(sub(needle, "", cmdArgs[match])))
  } else {
    # 'source'd via R console
    return(normalizePath(sys.frames()[[1]]$ofile))
  }
}

source( paste0(dirname(thisFile()), 'ReDCM_modelsearch.r') )
source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_utils.r') )
source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GES.r') )
source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GHD.r') )
source( paste0(dirname(thisFile()), 'ReDCM_modelsearch_GA.r') )


results = ReDCM.modelsearch(args[3], args[1], args[2])

# SCRIPT NOT FINISHED
# DO NOT USE

