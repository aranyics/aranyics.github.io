library('ReDCM')
library('ggplot2')
library('reshape2')

scriptdir = '~/research/modelsearch/scripts/1st_lvl/3_family/'
source( paste0(scriptdir, '../2_topological_search/ReDCM_modelsearch_utils.r') )

subjects = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')

ReDCM.modelspace.families = function(datadir, subject)
{
  
  figdir = paste0(datadir,'/results/figures/tmp/')
  
  #Amask = [0 1 1 0 1 0 0 1 1 0 0 1 0 1 1 0];
  templates = rbind(
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1),
    matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0), nrow = 1)
  )
  
  lr = c(1, 4, 7, 10, 13, 16, 19, 22, 25)
  l  = c(2, 5, 8, 11, 14, 17, 20, 23, 26)
  r  = c(3, 6, 9, 12, 15, 18, 21, 24, 27)
  
  vd = c(1, 2, 3, 10, 11, 12, 19, 20, 21)
  d  = c(4, 5, 6, 13, 14, 15, 22, 23, 24)
  v  = c(7, 8, 9, 16, 17, 18, 25, 26, 27)
  
  tt = c(1, 2, 3, 4, 5, 6, 7, 8, 9)
  t2 = c(19, 20, 21, 22, 23, 24, 25, 26, 27)
  t3 = c(10, 11, 12, 13, 14, 15, 16, 17, 18)
  
  database = ReDCM.make.database(datadir, subject[1])
  modelspace = database$info
  bitvectors = ReDCM.make.bitvectors(modelspace)
  
  families = apply( sapply(ReDCM.bitvector.to.id.multiple(templates, bitvectors), function(x){modelspace[x, c('B1', 'B2', 'B3')]}), 
                    2, function(x){modelspace$ID[which(modelspace$B1 == x[1] & modelspace$B2 == x[2] & modelspace$B3 == x[3])]})
  
  subjects.Fe.lr = NULL
  subjects.Fe.vd = NULL
  subjects.Fe.task = NULL
  for (s in subject)
  {
    database = ReDCM.make.database(datadir, s)
    modelspace = database$info
    
    subjects.Fe.lr   = rbind(subjects.Fe.lr, matrix(c(sum(modelspace$Fe[families[,l]]), sum(modelspace$Fe[families[,r]]), sum(modelspace$Fe[families[,lr]])), nrow = 1))
    subjects.Fe.vd   = rbind(subjects.Fe.vd, matrix(c(sum(modelspace$Fe[families[,v]]), sum(modelspace$Fe[families[,d]]), sum(modelspace$Fe[families[,vd]])), nrow = 1))
    subjects.Fe.task = rbind(subjects.Fe.task, matrix(c(sum(modelspace$Fe[families[,t3]]), sum(modelspace$Fe[families[,t2]]), sum(modelspace$Fe[families[,tt]])), nrow = 1))
  }
    
  lr.p = ReDCM_run_BMS( subjects.Fe.lr,
                   method = 'rfx',
                   model.names = c('Left', 'Right', 'Both') )
  vd.p = ReDCM_run_BMS( subjects.Fe.vd,
                   method = 'rfx',
                   model.names = c('Ventral', 'Dorsal', 'Both') )
  task.p = ReDCM_run_BMS( subjects.Fe.task,
                   method = 'rfx',
                   model.names = c('Words', 'Pictures', 'Both') )
    
  
  S = NULL
  for (f in dir(paste0(datadir, '/results/DCM_modelsearch'), pattern = subject, full.names = TRUE))
  {
    tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
    S = rbind(S, subset(tmp, data=='S'))
  }
  #S = subset(S, p.check==0)
  
  PLUS.POSTHOC.MODELS = c(60414, 65264, 61142, 63178, 63486, 48918, 64000, 65504, 52879, 59842)
  PLUS.POSTHOC.DF = data.frame(data="S", subject="", method="PH", p.check=0, run=1, iter=1, model=PLUS.POSTHOC.MODELS, Fe=0, dFe=0, dH=0, calc=0)
  S = rbind(S, PLUS.POSTHOC.DF)
  
  models = ReDCM.id.to.bitvector.multiple(S$model, modelspace)

  #matching.bits = t((models[1,-c(1:32)] == t(templates[,-c(1:32)]))) & t((models[1,-c(1:32)] == 1 | t(templates[,-c(1:32)]) == 1))
  matching.bits = apply( models, 1, function(x){
    equals  = t((x[-c(1:32)] == t(templates[,-c(1:32)])))
    any.on = t((x[-c(1:32)] == 1 | t(templates[,-c(1:32)]) == 1))
    max.match = rowSums(any.on * 1)
    100 / max.match * rowSums((equals & any.on) * 1)
  })
  best.match.to.templates = apply(matching.bits, 2, function(x){which(x == max(x))})
  
  fit.to.family.lr = t( sapply(best.match.to.templates, function(x){
    n = length(x)
    c(length(which(x %in% lr))/n, length(which(x %in% l))/n, length(which(x %in% r))/n)
  }) )
  fit.to.family.vd = t( sapply(best.match.to.templates, function(x){
    n = length(x)
    c(length(which(x %in% vd))/n, length(which(x %in% v))/n, length(which(x %in% d))/n)
  }) )
  fit.to.family.task = t( sapply(best.match.to.templates, function(x){
    n = length(x)
    c(length(which(x %in% tt))/n, length(which(x %in% t3))/n, length(which(x %in% t2))/n)
  }) )
  
  df.lr = data.frame(method=S$method, Left=fit.to.family.lr[,2], Right=fit.to.family.lr[,3], Both=fit.to.family.lr[,1])
  df.vd = data.frame(method=S$method, Ventral=fit.to.family.vd[,2], Dorsal=fit.to.family.vd[,3], Both=fit.to.family.vd[,1])
  df.wp = data.frame(method=S$method, Words=fit.to.family.task[,2], Pictures=fit.to.family.task[,3], Both=fit.to.family.task[,1])
  
  df.summ.lr = as.data.frame(t( 
    apply( array(c('GES', 'GHD', 'GA', 'PH')), 1, function(x){
      c(method=x, 100 / dim(subset(df.lr, method==x))[1] * colSums(subset(df.lr, method==x)[,-1])) })
  ))  
  df.summ.vd = as.data.frame(t( 
    apply( array(c('GES', 'GHD', 'GA', 'PH')), 1, function(x){
      c(method=x, 100 / dim(subset(df.vd, method==x))[1] * colSums(subset(df.vd, method==x)[,-1])) })
  ))  
  df.summ.wp = as.data.frame(t( 
    apply( array(c('GES', 'GHD', 'GA', 'PH')), 1, function(x){
      c(method=x, 100 / dim(subset(df.wp, method==x))[1] * colSums(subset(df.wp, method==x)[,-1])) })
  ))
  
  #df.summ = rbind(t(df.summ.lr)[-1,], t(df.summ.vd)[-1,], t(df.summ.wp)[-1,])
  #colnames(df.summ) = c('GES', 'GHD', 'GA', 'PH')
  #write.table(df.summ, paste0(figdir, 'table_famsrch.csv'), sep = ',', row.names = TRUE, col.names = TRUE)
  
  df.m.lr = melt(df.summ.lr, id.vars = 'method')
  df.m.lr$value = as.numeric(df.m.lr$value)
  g.lr = ggplot(df.m.lr, aes(variable, value, fill=method)) + geom_bar(stat = "identity", colour = "#222222", position = position_dodge(width = 0.8), width = 0.7) + ylim(c(0, 100)) +
    labs(y='Search percentage', x=NULL) + scale_fill_grey(start = 0.9, end = 0.15, name="Method") + theme_bw() +
    theme(axis.title.y = element_text(size=12), axis.text.x = element_text(size=12))
  g.lr
  ggsave( paste0(figdir, 'famsrch_lr.pdf'), width = 5, height = 4 )
  df.m.vd = melt(df.summ.vd, id.vars = 'method')
  df.m.vd$value = as.numeric(df.m.vd$value)
  g.vd = ggplot(df.m.vd, aes(variable, value, fill=method)) + geom_bar(stat = "identity", colour="#222222", position = position_dodge(width = 0.8), width = 0.7) + ylim(c(0, 100)) +
    labs(y='Search percentage', x=NULL) + scale_fill_grey(start = 0.9, end = 0.15, name="Method") + theme_bw() +
    theme(axis.title.y = element_text(size=12), axis.text.x = element_text(size=12))
  g.vd
  ggsave( paste0(figdir, 'famsrch_vd.pdf'), width = 5, height = 4 )
  df.m.wp = melt(df.summ.wp, id.vars = 'method')
  df.m.wp$value = as.numeric(df.m.wp$value)
  g.wp = ggplot(df.m.wp, aes(variable, value, fill=method)) + geom_bar(stat = "identity", colour="#222222", position = position_dodge(width = 0.8), width = 0.7) + ylim(c(0, 100)) +
    labs(y='Search percentage', x=NULL) + scale_fill_grey(start = 0.9, end = 0.15, name="Method") + theme_bw() +
    theme(axis.title.y = element_text(size=12), axis.text.x = element_text(size=12))
  g.wp
  ggsave( paste0(figdir, 'famsrch_wp.pdf'), width = 5, height = 4 )
  
  return (0)
  
}



ReDCM_run_BMS = function( Fe, method, model.names=NULL )
{
  
  N = NULL                                # number of subjects
  M = NULL                                # number of models
  sumF = 0
  if ( length( dim(Fe) ) < 2 )
  {
    # one subject -> fixed effect
    # method = 'ffx'
    N = 1
    M = length(Fe)
    sumF = Fe
  }
  else
  {
    N = dim(Fe)[1]
    M = dim(Fe)[2]
    sumF = colMeans(Fe)
  }
  
  if ( M < 2 )
  {
    cat('ReDCM_BMS: select more than one model\n')
    return ( 0 )
  }
  
  if ( method != 'ffx' && method != 'rfx' )
  {
    cat('ReDCM_BMS: unknown method (use \'ffx\' or \'rfx\')\n')
    return ( 0 )
  }
  
  
  # Bayesian Model Selection
  # ====================================================================================
  if ( method == 'ffx' )                # single subject, or fixed effects group BMS
  {
    names( sumF ) = model.names
    sumF = sumF - min( sumF )
    i = sumF < ( max( sumF ) - 32 )
    P = sumF
    P[which(i)] = max( sumF ) - 32
    P = P - min( P )
    P = exp( P )
    P = P / sum( P )
    
    barplot( sumF, ylab='Log-evidences', main=str_c('Bayesian Model Selection: ', toupper(method)) )
    barplot( P, ylim=c(0,1), ylab='Model Posterior Probability', main=str_c('Bayesian Model Selection: ', toupper(method)) )
    
    return( list(logF = sumF, P = P) )
  }
  else                                  # random effects BMS
  {
    bms     = ReDCM_BMS_gibbs( Fe )
    exp_r   = bms[[1]]
    xp      = bms[[2]]
    r_samp  = bms[[3]]
    g_post  = bms[[4]]
    
    # compute protected xp's
    # bms     = spm_BMS( Fe )
    # pxp     = bms[[1]]
    # bor     = bms[[2]]
    
    names( exp_r ) = model.names
    names( xp ) = model.names
    
    barplot( exp_r, ylab='Model Expected Probability', main=str_c('Bayesian Model Selection: ', toupper(method)) )
    barplot( xp, ylim=c(0,1), ylab='Model Exceedance Probability', main=str_c('Bayesian Model Selection: ', toupper(method)) )
    
    return( list(exp_r = exp_r, xp = xp) )
  }
  
  return( 0 )
  
}
