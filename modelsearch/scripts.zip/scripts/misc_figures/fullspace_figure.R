library('mclust')
library('cowplot')
library('scales')
library('plyr')
library('ggplot2')

scriptdir = '~/research/modelsearch/results/figures/'
source( paste0(scriptdir, '../../scripts/1st_lvl/2_topological_search/ReDCM_modelsearch_utils.r') )

projdir = '~/research/modelsearch/'
subjects = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')

# posthoc s01:
# Pp.A
#   0.5001    0.9072    0.9224       NaN
# 0.9125    0.5000       NaN    0.9982
# 0.9546       NaN    0.5002    0.9999
# NaN    0.5030    0.5014    0.8634
# 
# Pp.B(,,2:3)
#   0.8828       NaN       NaN       NaN
# NaN    0.9984       NaN       NaN
# NaN       NaN    0.9921       NaN
# NaN       NaN       NaN    0.9860
# 
#   0.9236       NaN       NaN       NaN
# NaN    0.9756       NaN       NaN
# NaN       NaN    0.5002       NaN
# NaN       NaN       NaN    0.9950

full.bv = 'b1110110110110111000000000000000010000100001000011000010000100001'

posthoc.bv = c(
posthoc.s01 = 'b1110110010100111000000000000000010000100001000011000010000000001',
posthoc.s02 = 'b1110110110110101000000000000000010000100001000001000010000100001',
posthoc.s03 = 'b1110110010110101000000000000000010000100000000010000010000000001',
posthoc.s04 = 'b1110110100110101000000000000000010000100000000001000000000000001',
posthoc.s05 = 'b1110110100110111000000000000000010000100001000011000010000000001',
posthoc.s06 = 'b1100110110110111000000000000000000000000000000010000010000000001',
posthoc.s07 = 'b1110110110100011000000000000000010000100001000011000010000100001',
posthoc.s08 = 'b1110110110110111000000000000000010000100000000011000010000100001',
posthoc.s09 = 'b1110010010110101000000000000000010000000000000001000010000100000',
posthoc.s10 = 'b1110110010100011000000000000000010000100000000000000000000000001'
)

# posthoc.IDs = apply( array(1:10), 1, function(x){
#  db = ReDCM.make.database( projdir, subjects[x], bmr.ms = TRUE )
#  return(which(db$info$bitvector == posthoc.bv[x]))
# } )
# posthoc.Fe = apply( array(1:10), 1, function(x){
#   db = ReDCM.make.database( projdir, subjects[x], bmr.ms = TRUE )
#   return(db$info$dFe[which(db$info$bitvector == posthoc.bv[x])])
# } )
# posthoc.dH = apply( array(1:10), 1, function(x){
#   db = ReDCM.make.database( projdir, subjects[x], bmr.ms = TRUE )
#   return(db$info$dHD[which(db$info$bitvector == posthoc.bv[x])])
# } )
#posthoc.ID = c(60414)


#correlation of dFe and dH
#all.subj = array(c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10'))
#mean(apply(all.subj, 1, function(x){db = ReDCM.make.database('~/research/modelsearch/', x); cor.test(db$info$dFe, db$info$dHD)$estimate}))
#[1] -0.3004687
#mean(apply(all.subj, 1, function(x){db = ReDCM.make.database('~/research/modelsearch/', x, bmr.ms = TRUE); cor.test(db$info$dFe, db$info$dHD)$estimate}))
#[1] -0.4544173


S.dcm = NULL
for (f in dir(paste0(projdir, '/results/DCM_modelsearch'), pattern = '20.csv', full.names = TRUE))
{
  tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
  S.dcm = rbind(S.dcm, subset(tmp, data=='S'))
}
S.bmr = NULL
for (f in dir(paste0(projdir, '/results/BMR_modelsearch'), pattern = '20.csv', full.names = TRUE))
{
  tmp = read.csv(f, sep = ',', header = TRUE, stringsAsFactors = FALSE)
  S.bmr = rbind(S.bmr, subset(tmp, data=='S'))
}

rdcm.ms.modelsearch.boxplot = function( S, projdir )
{
  all.subj = array(c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10'))
  # ranges = apply( all.subj, 1, function(x){
  #   db = ReDCM.make.database( projdir, x )
  #   return(c(min(db$info$dFe), max(db$info$dFe)))
  # } )
  ranges = matrix( c( -43.7996, 0, -140.6828, 0, -31.3182, 0, -109.8169, 0, -45.6287, 0, -61.0146, 0, -67.6773, 0, -271.0927, 0, -52.0495, 0, -16.613, 0 ),
                   nrow = 2)
  
  for (i in 1:length(all.subj))
  {
    S$dFe[which(S$subject == all.subj[i])] = S$dFe[which(S$subject == all.subj[i])] / ranges[1,i]
  }
  
  S.s01 = subset(S, subject=='s01')
  
  outdir = paste0(projdir, '/results/figures/')
  
  gg = ggplot(S, aes(method, dH, fill=p.check == 1)) + geom_boxplot() +
    theme_bw() + scale_fill_grey(start=0.9, end=0.6, name="Search method", labels = c('not optimized', 'optimized')) +
    theme( axis.title.x = element_blank(), axis.text.x = element_text(size=10),
           axis.title.y = element_text(size = 14), axis.text.y = element_text(size=10),
           legend.title.align = 0.5, legend.key.height = unit(0.3, 'in') )
  ggsave(paste0(outdir, 'rdcm_search_dH.pdf'), width=4, height=4)
  gg = ggplot(S, aes(method, dFe, fill=p.check == 1)) + geom_boxplot() +
    theme_bw() + scale_fill_grey(start=0.9, end=0.6, name="Search method", labels = c('not optimized', 'optimized')) +
    theme( axis.title.x = element_blank(), axis.text.x = element_text(size=10),
           axis.title.y = element_text(size = 14), axis.text.y = element_text(size=10),
           legend.title.align = 0.5, legend.key.height = unit(0.3, 'in') )
  ggsave(paste0(outdir, 'rdcm_search_dFe.pdf'), width=4, height=4)
  gg = ggplot(S, aes(method, calc, fill=p.check == 1)) + geom_boxplot() +
    theme_bw() + scale_fill_grey(start=0.9, end=0.6, name="Search method", labels = c('not optimized', 'optimized')) + labs(y='Number of models', x=NULL)
    theme( axis.title.x = element_blank(), axis.text.x = element_text(size=10),
           axis.title.y = element_text(size = 14), axis.text.y = element_text(size=10),
           legend.title.align = 0.5, legend.key.height = unit(0.3, 'in') )
  ggsave(paste0(outdir, 'rdcm_search_calc.pdf'), width=4, height=4)
  
  # gg = ggplot(S, aes(method, dFe, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
  # gg = ggplot(S, aes(method, dH, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
  # gg = ggplot(S, aes(method, calc, colour=p.check == 1)) + geom_boxplot() + geom_point(position=position_jitterdodge(0.2, 0.2, 0.75)) + facet_grid(.~subject)
  # 
  # 
  # gg = ggplot(s01.ms, aes(method, dH)) + geom_boxplot() + geom_jitter(position=position_jitter(0.2)) + facet_grid(.~p.check)
  # gg = ggplot(s01.ms, aes(method, calc)) + geom_boxplot() + geom_jitter(position=position_jitter(0.2)) + facet_grid(.~p.check)
  
}


myMedian = function(data)
{
  return( sort(data)[ floor(length(data)/2) + 1 ] )
}


rdcm.ms.classify.dFe = function(projdir, subject, S, bmr=FALSE, msga=NULL, nsample=NULL, ref.mID = NULL)
{
  
  posthoc.dFe = array(c(-1.2656,  0.0000, -0.9190, -0.7726, -1.5817, -0.3870, -0.2640, -0.7371, -0.0805, -1.2689))
  names(posthoc.dFe) = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')
  posthoc.dH = array(c(3, 0, 3, 2, 1, 2, 1, 2, 1, 6))
  names(posthoc.dH) = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')
  posthoc.dcm.dFe = array(c(-2.0679, -51.2692,  -6.6530, -40.6891,  -9.0456, -31.5624,  -3.1311, -23.9170,  -0.2652,  -0.9617))
  names(posthoc.dcm.dFe) = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')
  posthoc.dcm.dH = array(c(3, 5, 8, 6, 3, 8, 3, 2, 3, 7))
  names(posthoc.dcm.dH) = c('s01', 's02', 's03', 's04', 's05', 's06', 's07', 's08', 's09', 's10')
  
  db = ReDCM.make.database(projdir, subject)
  df.dcm = db$info
  colnames(df.dcm)[which(colnames(df.dcm) == 'dHD')] = 'dH'
  df.dcm$dFe = abs(df.dcm$dFe)
  
  db = ReDCM.make.database(projdir, subject, bmr.ms = TRUE)
  df.bmr = db$info
  colnames(df.bmr)[which(colnames(df.bmr) == 'dHD')] = 'dH'
  bmr.dFe.max = max(df.bmr$dFe)
  df.bmr$dFe = df.bmr$dFe - max(df.bmr$dFe)
  df.bmr$dFe = abs(df.bmr$dFe)
  
  if (!bmr)
    df.o = df.dcm
  else
    df.o = df.bmr
  
  outdir = paste0(projdir, '/results/figures/')
  
  S.subj = subset(S, subject == subject)
  S.GES = subset(S.subj, method == 'GES')
  S.GHD = subset(S.subj, method == 'GHD')
  S.GA = subset(S.subj, method == 'GA')
  
  if (!is.null(ref.mID))
  {
    df.o$dFe = df.o$Fe[df.o$mID == ref.mID] - df.o$Fe
    dFe.limits = c(min(df.o$dFe), quantile(df.o$dFe, 0.97))
  }
  else
  {
    if (!bmr)
      #dFe.limits = c(0, max(df.o$dFe)+10)
      dFe.limits = c(min(df.o$dFe), quantile(df.o$dFe, 0.99))
    else
      dFe.limits = c(min(df.o$dFe), quantile(df.o$dFe, 0.90))
  }
  
  
  if (!is.null(nsample) && dim(df.o)[1] >= nsample)
  {
    ns = runif(nsample, 1, dim(df.o)[1])
    df = df.o[ns, ]
  }
  else
  {
    df = df.o
  }
  
  if ( !is.null(msga) )
  {
    msga = read.table(msga, header=TRUE, sep=',', stringsAsFactors=FALSE)
    models = adply(1:max(msga$run), 1, function(x){
      l = tail(msga[which(msga$run == x),],1);
      colnames(l)[c(4,5)] = c('dFe', 'dH');
      l[,'dFe'] = max(csvfile$Fe) - l[,'dFe'];
      return (l)
    })
  }
  else
  {
    
    #models = data.frame(name = c('Suggested', 'Best', 'Best.BMR', 'Search', 'Full'), dH = c(10, 0.1, 6, 8, 8), dFe = c(258.1, 3.0, 197.62, 29.56, 478.1))
    #models = data.frame(name = c('Suggested', 'Best', 'Best.BMR', 'Search', 'Full'), dH = c(14, 6, 0.1, 6, 6), dFe = c(175.5, 44.94, 3.0, 21.45, 6.57))
    if (!bmr)
    {
      models = data.frame(name = c('Best.DCM', 'Best.BMR', 'GES', 'GHD', 'GA', 'posthoc'),
                          dH = c(0.1, abs(df.dcm$dH[which(df.dcm$mID == df.bmr$mID[which(df.bmr$Fe == max(df.bmr$Fe))])]),
                                 abs(mean(S.GES$dH)), 
                                 abs(mean(S.GHD$dH)), 
                                 abs(mean(S.GA$dH)),
                                 posthoc.dcm.dH[subject]),
                          dFe = c(0.5, abs(df.dcm$dFe[which(df.dcm$mID == df.bmr$mID[which(df.bmr$Fe == max(df.bmr$Fe))])]), 
                                  abs(mean(S.GES$dFe)), abs(mean(S.GHD$dFe)), abs(mean(S.GA$dFe)),
                                  abs(posthoc.dcm.dFe[subject]))
                          )
    }
    else
    {
      models = data.frame(name = c('Best.DCM', 'Best.BMR', 'GES', 'GHD', 'GA', 'posthoc'),
                          dH = c(abs(df.bmr$dH[which(df.bmr$mID == df.dcm$mID[which(df.dcm$Fe == max(df.dcm$Fe))])]), 0.1, abs(mean(S.GES$dH)), abs(mean(S.GHD$dH)), abs(mean(S.GA$dH)), posthoc.dH[subject]),
                          dFe = c(abs(df.bmr$dFe[which(df.bmr$mID == df.dcm$mID[which(df.dcm$Fe == max(df.dcm$Fe))])]), 0.5, abs(mean(S.GES$dFe))+bmr.dFe.max, abs(mean(S.GHD$dFe))+bmr.dFe.max, abs(mean(S.GA$dFe))+bmr.dFe.max, abs(posthoc.dFe[subject])+bmr.dFe.max))
    }
    models = models
  }
  
  if ( ! ("dFe.mclust" %in% colnames(df)) )
  {
    dFe_mclust = densityMclust(df$dFe)
    df = cbind(df, dFe_mclust$classification)
    colnames(df)[dim(df)[2]] = 'dFe.mclust'
    df$dFe.mclust = as.factor(df$dFe.mclust)
    df$wgth = count(df$dFe.mclust)[df$dFe.mclust,2] / count(df$dFe.mclust)[,2]
  }  
  
  margin.density = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute, fill = cluster)) +
      geom_density(aes(weight=wgth), alpha = 0.2, adjust=2) +
      #geom_density(alpha = 0.2, adjust=2) +
      #scale_colour_branded(other = "yellow") + 
      #scale_y_continuous(labels=percent) +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin())
    if ( attribute == 'dFe' ) 
      g = g + scale_x_continuous(expand = c(0,0), limits = dFe.limits) + geom_histogram(aes(weight = 0.002), alpha=0.2, bins = 100)
    return(g)
  }
  margin.hist = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute, color = cluster, fill = cluster)) +
      geom_histogram(alpha=0.2, position="identity") +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin())
    
    return(g)
  }
  margin.hist2 = function(table, attribute, cluster)
  {
    g = ggplot(table, aes_string(attribute)) +
      geom_histogram() +
      guides(color=FALSE, fill=FALSE, alpha=FALSE) +
      theme_void() +
      theme(plot.margin = margin()) 
    return(g)
  }
  
  main.density2d = ggplot(df, aes(x=dH, y = dFe)) + #, color = dFe.mclust, fill = dFe.mclust)) +
    #stat_density_2d(aes(alpha= ..level.., fill= ..level..), geom='polygon', bins=200) +
    #scale_fill_gradient(low = "red", high = "yellow") +
    stat_density_2d(aes(fill= ..density..), geom='raster', contour=FALSE, n=100, h=c(2.5, 20)) +
    scale_fill_distiller(palette= "Spectral", direction=-1) +
    scale_x_continuous(expand=c(0,0), limits=c(0, 16), breaks=c(0, 2, 4, 6, 8, 10, 12, 14, 16)) +
    scale_y_continuous(expand=c(0,0), limits=dFe.limits, breaks=seq(0, max(df$dFe), 10)) +
    guides(color = FALSE, alpha = FALSE, fill=FALSE) +
    xlab(label="Hd") +
    theme(plot.margin = margin())
  main.density2d.mod = main.density2d +
    geom_point(data=models, aes(x=dH, y = dFe), label=names)# + geom_text(data=models, x=models$dH, y=models$dFe, label=models$name, size=3, hjust=-0.15, vjust=-0.2)
  #geom_point(data=models, aes(x=dH, y = dFe), size = 1)
  main.scatter = ggplot(df, aes(x=dH, y = dFe, color = dFe.mclust)) +
    geom_point(position='jitter') +
    scale_x_continuous(expand=c(0,0), limits=c(0, 18), breaks=c(0, 2, 4, 6, 8, 10, 12, 14, 16)) +
    scale_y_continuous(expand=c(0,0), limits=c(0, 1100), breaks=seq(0, max(df$dFe), 10)) +
    guides(color = FALSE, alpha = FALSE) +
    xlab(label="Hd") +
    theme(plot.margin = margin())
  
  main.plot = main.density2d
  margin.x = margin.density(df, "dH", "dFe.mclust")
  margin.y = margin.density(df, "dFe", "dFe.mclust") + coord_flip()
  margin.x.aligned = align_plots(margin.x, main.plot, align='v')[[1]]
  margin.y.aligned = align_plots(margin.y, main.plot, align='h')[[1]]
  
  full.plot = plot_grid(
    margin.x.aligned
    , NULL
    , main.plot
    , margin.y.aligned
    , ncol = 2
    , nrow = 2
    , rel_heights = c(0.3, 1)
    , rel_widths = c(1, 0.4)
  )
  
  full.plot
  
  ggsave(paste0(outdir, 'rdcm_ms_cowplot4.pdf'), width=6, height=5)
  
  main.plot = main.density2d.mod
  full.plot = plot_grid(
    margin.x.aligned
    , NULL
    , main.plot
    , margin.y.aligned
    , ncol = 2
    , nrow = 2
    , rel_heights = c(0.3, 1)
    , rel_widths = c(1, 0.4)
  )
  
  full.plot
  
  ggsave(paste0(outdir, 'rdcm_ms_cowplot4_mod.pdf'), width=6, height=5)
  
  return( full.plot )
}

branded_colors <- list(
  "blue"   = "#00798c",
  "red"    = "#d1495b",
  "yellow" = "#edae49",
  "green"  = "#66a182",
  "navy"   = "#2e4057", 
  "grey"   = "#8d96a3"
)

branded_pal <- function(
  primary = "blue", 
  other = "grey", 
  direction = 1
) {
  stopifnot(primary %in% names(branded_colors))
  
  function(n) {
    if (n > 6) warning("Branded Color Palette only has 6 colors.")
    
    if (n == 2) {
      other <- if (!other %in% names(branded_colors)) {
        other
      } else {
        branded_colors[other]
      }
      color_list <- c(other, branded_colors[primary])
    } else {
      color_list <- branded_colors[1:n]
    }
    
    color_list <- unname(unlist(color_list))
    if (direction >= 0) color_list else rev(color_list)
  }
}

scale_colour_branded <- function(
  primary = "blue", 
  other = "grey", 
  direction = 1, 
  ...
) {
  ggplot2::discrete_scale(
    "colour", "branded", 
    branded_pal(primary, other, direction), 
    ...
  )
}
