function [res] = ms_dcm_isvalid(DCM)

    res = 1;
    vect = ms_dcm2vect(DCM);
    for i = [1:DCM.n*DCM.n]
        for j = [1:length(DCM.U.name)]
            if (vect(i) < vect(i+j*DCM.n*DCM.n))
                res = 0;
                return
            end
        end
    end

end
