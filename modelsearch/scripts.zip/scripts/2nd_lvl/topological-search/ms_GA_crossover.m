function [DCM] = ms_GA_crossover(DCM1, DCM2)

    [bitvect1 idx1] = ms_dcm2vect(DCM1);
    [bitvect2 idx2] = ms_dcm2vect(DCM2);
    
    cp = randperm(length(bitvect1), 2);
    while ~any(bitvect1(min(cp):max(cp)) == bitvect2(min(cp):max(cp)))
        cp = randperm(length(bitvect1), 2);
    end
    
    bitvect1(min(cp):max(cp)) = bitvect2(min(cp):max(cp));
    
    DCM = ms_vect2dcm(DCM1, bitvect1);

end
