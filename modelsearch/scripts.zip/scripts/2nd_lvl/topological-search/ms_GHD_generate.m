function [GCM, searched] = ms_GHD_generate(DCM, idx, searched)

    GCM{1} = DCM;
    nls = size(searched.models,2);
    if nls == 0
        searched.models = ms_dcm2vect(DCM);
    else
        searched.models(:,end+1) = ms_dcm2vect(DCM);
    end
    disabled = find(eye(DCM.n, DCM.n));

    for i = 1:length(idx)
        if any(idx(i) == disabled )
            continue
        end
        tmp = ms_dcm2vect(DCM);
        tmp(idx(i)) = 1 - tmp(idx(i));
        if any( all(tmp == searched.models, 1) )
            continue
        end
        tmpDCM = ms_vect2dcm(DCM, tmp);
        if ~ms_dcm_isvalid(tmpDCM)
            continue
        end
        GCM{end+1} = tmpDCM;
        searched.models(:,end+1) = tmp;
    end
    
    GCM = GCM';

end
