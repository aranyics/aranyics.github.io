1. modelsearch.m is a Matlab function to call model search algorithms on a 2nd lvl PEB model
