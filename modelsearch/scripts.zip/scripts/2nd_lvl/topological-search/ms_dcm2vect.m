function [vect idx] = ms_dcm2vect(DCM)

    vect = [ reshape(DCM.a, 1, numel(DCM.a)) reshape(DCM.b, 1, numel(DCM.b)) ]';
    idx = find(vect);

end