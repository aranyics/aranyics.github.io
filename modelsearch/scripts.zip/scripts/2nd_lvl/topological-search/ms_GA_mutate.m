function [DCM] = ms_GA_mutate(DCM, idx, minb, maxb, p0)

    disabled = find(eye(DCM.n, DCM.n));
    [m k] = ismember(disabled, idx);
    idx(k) = [];

    ntochange = randi([minb, maxb], 1);
    tochange = idx( randperm(length(idx), ntochange) );
    ptochange = tochange( find( (p0 - rand(ntochange,1)) > 0 ) );
    
    bitvect = ms_dcm2vect(DCM);
    bitvect(ptochange) = 1 - bitvect(ptochange);
    
    DCM = ms_vect2dcm(DCM, bitvect);

end
