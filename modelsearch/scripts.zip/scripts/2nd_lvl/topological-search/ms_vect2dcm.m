function [DCM] = ms_vect2dcm(DCM, bitvector)

    DCM.a = reshape( bitvector(1:DCM.n*DCM.n), DCM.n, DCM.n );
    Nexternal = length(DCM.U.name);
    DCM.b = reshape( bitvector(DCM.n*DCM.n+1:end), DCM.n, DCM.n, Nexternal );

end
