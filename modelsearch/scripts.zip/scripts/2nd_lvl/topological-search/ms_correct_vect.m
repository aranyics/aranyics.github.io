function [vect] = ms_correct_vect(vect, DCM)

    nu = size(DCM.U.u, 2);
    for i = 1:nu
        vect((i*DCM.n*DCM.n+1):((i+1)*DCM.n*DCM.n)) = vect(1:DCM.n*DCM.n) .* ... 
                                                      vect((i*DCM.n*DCM.n+1):((i+1)*DCM.n*DCM.n));
    end

end