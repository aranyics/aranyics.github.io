function [GCM] = ms_GA_init(DCM, k)

    [bitvect idx] = ms_dcm2vect(DCM);
    basevect = zeros(length(bitvect), 1);
    basevect(1:DCM.n*DCM.n) = reshape(eye(DCM.n), DCM.n*DCM.n, 1);
    
    tmp = 1 * (basevect | randi([0,1], length(bitvect), 1));
    tmp = ms_correct_vect( tmp .* bitvect, DCM ); %assumes full model
    
    GCM{1} = ms_vect2dcm(DCM, tmp);
    for i = 2:k
        GCM{i} = ms_GA_mutate(GCM{1}, idx, 8, 8, 1.0);
    end

end
