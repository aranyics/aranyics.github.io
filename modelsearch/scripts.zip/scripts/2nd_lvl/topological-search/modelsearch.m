function [DCM searched] = modelsearch(P, DCM, mode)

% 1. Loading PEB/DCM model and base DCM model
if isfield(P, 'Snames')
    P = P;
end

clear GCM;
clear searched;


% 2. Options (searching method, parameter check)
ntop = 1;
iter = 0;
notconverged = 1;
forward_GES = 1;



% 3. Set starting model(s)
[bitvect idx] = ms_dcm2vect(DCM);
searched.models = ones(length(bitvect),0);
searched.iter = zeros(0);
searched.Fe = zeros(0);
if strcmp(mode, 'GHD') || strcmp(mode, 'GES')
    DCM = DCM;    
elseif strcmp(mode, 'GA')
    ntop = 4;
    notconverged = 4;
    GCM = ms_GA_init(DCM, ntop);
    DCM = GCM{1};
end




% 4. Main loop
while notconverged
    
    iter = iter + 1;


    % 4.1. Generate model alternatives
    if strcmp(mode, 'GHD')
        [GCM searched] = ms_GHD_generate(DCM, idx, searched);
        %GCM = GCM';
    elseif strcmp(mode, 'GES')
        [GCM searched] = ms_GES_generate(DCM, idx, forward_GES, searched);
        %GCM = GCM';
    elseif strcmp(mode, 'GA')
        [GCM searched] = ms_GA_generate(GCM, idx, searched);
    end

    searched.iter(length(searched.iter)+1:size(searched.models,2)) = iter;



    % 4.2. Evaluate models (comparing BMR results)
    if strcmp(mode, 'posthoc')
        BMA = spm_dcm_peb_bmc(P);
        break
    else
        BMA = spm_dcm_peb_bmc(P, GCM);
    end
    % averaging (rfx?) model evidence (mean BMA.F 2) and summing
    % hatareloszlas model probability (sum BMA.P 2) along commonalities to
    % select next model, the other regressors are not selected for model
    % comparison
    Prob = sum(BMA.P, 2);
    Fe = mean(BMA.F, 2);

    searched.Fe(length(searched.Fe)+1:size(searched.models,2)) = Fe;


    % 4.3. Select winning model(s)
    [best bestIdx] = sort(Prob, 'descend');
    if strcmp(mode, 'GHD') || strcmp(mode, 'GES')
        if all(ms_dcm2vect(DCM) == ms_dcm2vect(GCM{bestIdx(1)}))
            notconverged = 0;
            if strcmp(mode, 'GES') && forward_GES
                notconverged = 1;
                forward_GES = 0;
            end
        else
            DCM = GCM{bestIdx(1)};
        end
    elseif strcmp(mode, 'GA')
        if iter >= 50
            DCM = GCM{bestIdx(1)};
            GCM = GCM(bestIdx(1:ntop));
            break
        end
        if all(ms_dcm2vect(DCM) == ms_dcm2vect(GCM{bestIdx(1)}))
            notconverged = notconverged - 1;
            DCM = GCM{bestIdx(1)};
            GCM = GCM(bestIdx(1:ntop));
        else
            notconverged = 4;
            DCM = GCM{bestIdx(1)};
            GCM = GCM(bestIdx(1:ntop));
        end
    end


end

if strcmp(mode, 'GA')
    DCM = GCM;
end
if strcmp(mode, 'posthoc')
    DCM = BMA;
end

%searched.models = searched.models';
%searched.Fe = searched.Fe';
%searched.iter = searched.iter';

end
