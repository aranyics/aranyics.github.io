function [GCM, searched] = ms_GES_generate(DCM, idx, fw, searched)

    GCM{1} = DCM;
    nls = size(searched.models,2);
    if nls == 0
        searched.models = ms_dcm2vect(DCM);
    else
        searched.models(:,end+1) = ms_dcm2vect(DCM);
    end
    disabled = find(eye(DCM.n, DCM.n));

    for i = 1:length(idx)
        if any(idx(i) == disabled ) % continue if disabled
            continue
        end
        tmp = ms_dcm2vect(DCM);
        if fw                       % continue based on forward/bw search
            if tmp(idx(i)) == 0
                continue
            end
        else
            if tmp(idx(i)) == 1
                continue
            end
        end
        tmp(idx(i)) = 1 - tmp(idx(i));
        if any( all(tmp == searched.models, 1) ) % continue if not avail.
            continue
        end
        tmpDCM = ms_vect2dcm(DCM, tmp);
        if ~ms_dcm_isvalid(tmpDCM)     % continue if DCM not valid
            continue
        end
        GCM{end+1} = tmpDCM;
        searched.models(:,end+1) = tmp;
    end
    
    GCM = GCM';

end
