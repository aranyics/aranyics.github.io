function [GCM searched] = ms_GA_generate(GCM, idx, searched)

    n = length(GCM);

    for i = 1:n
        searched.models(:,end+1) = ms_dcm2vect(GCM{i});
    end

    % crossover
    for i = 1:(n-1)
        for j = (i+1):n
            available = 0;
            k = 1;
            while ~available
                if (k > 100)
                    % mutate rather
                    DCM = ms_GA_mutate(GCM{i}, idx, 2, 8, 0.5);
                end
                if (k > 110)
                    fprintf("timed out %d\n", i);
                    break;
                end
                
                DCM = ms_GA_crossover(GCM{i}, GCM{j});
                k = k+1;
                if ( any( all(ms_dcm2vect(DCM) == searched.models, 1) ) )
                    continue
                end
                if ( ~ms_dcm_isvalid(DCM) )
                    continue
                end
                GCM{end+1} = DCM;
                searched.models(:,end+1) = ms_dcm2vect(DCM);
                available = 1;
            end
        end
    end
    
    % mutate
    for i = 1:length(GCM)
        available = 0;
        k = 1;
        while ~available
            if (k > 10) % timeout
                fprintf("timed out %d\n", i);
                break
            end
            k = k+1;
            
            DCM = ms_GA_mutate(GCM{i}, idx, 2, 8, 0.5);
            if ( any( all(ms_dcm2vect(DCM) == searched.models, 1) ) )
                continue
            end
            if ( ~ms_dcm_isvalid(DCM) )
                continue
            end
            GCM{end+1} = DCM;
            searched.models(:,end+1) = ms_dcm2vect(DCM);
            available = 1;
        end
    end

end
