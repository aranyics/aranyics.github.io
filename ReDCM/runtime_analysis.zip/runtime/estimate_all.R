#source('~/R/rdcm/R/rdcm_estimate.r')
#library('redcm')


setwd('/mnt/raid6_data/user/aranyics/modelspace/runtime/redcm/')

# Redirect output to file
con <- file("log.txt")
sink(con, append=TRUE)
sink(con, append=TRUE, type="message")


# De computations
#source("estim.R", echo=TRUE, max.deparse.length=10000)
files = dir()
for (f in files)
{
  cat(f)
  rdcm_estimate(f)
}


# Restore output to console
sink() 
sink(type="message")
