1. First, we generated models with 2 random (simulated event-related) inputs, by DCM.v scan length (200, 400, 600, 800, 1000, 1200) and DCM.n number of regions (3, 5, 7).

run generatemodel.m

2. Then we estimated them with Matlab:

run estimate_all.m

3. and R:

source estimate_all.R

4. Finally, the raw output was arranged by hand into a table summarizing mean running time of 1 EM cycle:
(This script is lost, but was working on the log.txt files)

results.csv

5. Result figures were created:

source runtime_results.R
