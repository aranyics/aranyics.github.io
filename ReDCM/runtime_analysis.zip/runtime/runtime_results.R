library('ggplot2')

setwd('/mnt/raid6_data/user/aranyics/modelspace/runtime/')

TR = read.table('summary_runtime.csv', sep=',', header=TRUE)

byregion = rbind( data.frame(method='DCM12', runtime=TR$Tem_matlab[c(4, 10, 16)], x=c(3, 5, 7)),
                  data.frame(method='ReDCM', runtime=TR$Tem_r[c(4, 10, 16)], x=c(3, 5, 7)) )

bylength = rbind( data.frame(method='DCM12', runtime=TR$Tem_matlab[c(9:12, 7:8)], x=seq(200, 1200, 200)),
                  data.frame(method='ReDCM', runtime=TR$Tem_r[c(9:12, 7:8)], x=seq(200, 1200, 200)) )

g1 = ggplot(byregion, aes(x=x, y=runtime, fill=method)) + geom_bar(stat='identity', position=position_dodge(), color='black')
g1 = g1 + geom_text(aes(label=runtime), vjust=-0.5, color="black", position=position_dodge(1.8), size=3)
g1 = g1 + scale_x_continuous(name= "Model size", breaks=c(3, 5, 7), labels=c('3 ROIs', '5 ROIs', '7 ROIs')) + theme(axis.title.x=element_text(size=14))
g1 = g1 + scale_y_continuous(name= "Running time (s)", breaks=seq(0, 100, 20)) + theme(axis.title.y=element_text(size=14))
g1 = g1 + scale_fill_manual(values=c('#FCB30C', '#5998E7')) + theme(legend.position=c(0.12, 0.86), legend.title=element_blank(), legend.text=element_text(size=12))
ggsave('runtime_size.pdf', width=6, height=4)


g2 = ggplot(bylength, aes(x=x, y=runtime, fill=method)) + geom_bar(stat='identity', position=position_dodge(), color='black')
g2 = g2 + geom_text(aes(label=runtime), vjust=-0.5, color="black", position=position_dodge(180), size=3)
g2 = g2 + scale_x_continuous(name= "Time-series length (scans)", breaks=c(200, 400, 600, 800, 1000, 1200)) + theme(axis.title.x=element_text(size=14))
g2 = g2 + scale_y_continuous(name= "Running time (s)", breaks=seq(0, 100, 20)) + theme(axis.title.y=element_text(size=14))
g2 = g2 + scale_fill_manual(values=c('#FCB30C', '#5998E7')) + theme(legend.position=c(0.12, 0.86), legend.title=element_blank(), legend.text=element_text(size=12))
ggsave('runtime_length.pdf', width=6, height=4)
