projdir = './matlab';

diary( fullfile( projdir, 'log.txt' ) )

files = dir2(projdir);

for k = 1 : length(files)
    if strcmp( files(k).name, 'log.txt')
        continue
    end
    files(k).name
    spm_dcm_estimate( fullfile(projdir, files(k).name) );
end

diary off
