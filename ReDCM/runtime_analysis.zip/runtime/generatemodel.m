clear DCM

%Options
DCM.n = 7;     % #regions
DCM.v = 400;   % #frames
uN = 2;        % #inputs
TR = 2;
microtime = 16;
input_density = 0.2;

%Model posterior definition
if DCM.n == 3
    DCM.Ep.A = [-0.40   0.01   0.24; ...
                -0.10   -0.37  0.32; ...
                0.12    0.01   -0.38];
    DCM.Ep.B = abs(rand(DCM.n, DCM.n, uN)*0.2);
    DCM.Ep.C = [0.32    0.02; ...
                0.05    0.04; ...
                0.01    0.24];
    DCM.Ep.D = zeros(DCM.n, DCM.n, 0);
    DCM.Ep.transit = [0.035; 0.052; 0.144];
    DCM.Ep.decay   = [-4.430e-04; 8.317e-05; 0.0193];
    DCM.Ep.epsilon = 0.105;
end
if DCM.n == 5
    DCM.Ep.A = [-0.0351    0.1829   -0.0819   -0.0891   -0.0851; ...
                 0.1949   -0.1524   -0.1998    0.0061   -0.1093; ...
                -0.1569   -0.3551   -0.1244    0.0976    0.1719; ...
                -0.0906    0.0729   -0.2496   -0.0009   -0.1391; ...
                -0.0834   -0.2760    0.2608    0.1619   -0.0277];
    DCM.Ep.B = abs(rand(DCM.n, DCM.n, uN)*0.2);
    DCM.Ep.C = [-0.0731    0.2034; ...
                -0.1889    0.0240; ...
                -0.1547    0.0319; ...
                 0.0518    0.1176; ...
                 0.0125    0.0337];
    DCM.Ep.D = zeros(DCM.n, DCM.n, 0);
    DCM.Ep.transit = [-0.0393;   -0.0009;    0.0200;   -0.0988;   -0.0325];
    DCM.Ep.decay   = [-0.0198;    0.0120;    0.0178;   -0.0308;    0.0345];
    DCM.Ep.epsilon = 0.0750;
end
if DCM.n == 7
    DCM.Ep.A = [-0.2838    0.0303   -0.0714    0.2046   -0.0120   -0.2919   -0.1078; ...
                 0.2481    0.0053    0.0156    0.0896   -0.0148   -0.1498   -0.0548; ...
                -0.1500   -0.1563   -0.1392    0.2666    0.3230    0.0730   -0.0847; ...
                 0.1164    0.1932    0.0295   -0.3541   -0.1514    0.0972   -0.1472; ...
                -0.1063    0.0748    0.1880   -0.0414   -0.1070    0.0250    0.3637; ...
                 0.0971    0.1593    0.3127   -0.0518    0.1613   -0.0908   -0.3608; ...
                -0.3240   -0.0033   -0.1674   -0.0694   -0.2074    0.1177   -0.2201];
    DCM.Ep.B = abs(rand(DCM.n, DCM.n, uN)*0.2);
    DCM.Ep.C = [0.0243    0.2329; ...
                0.2584   -0.0678; ...
               -0.1835    0.0520; ...
                0.1451    0.3214; ...
               -0.0038    0.0018; ...
                0.2220    0.2632; ...
               -0.0680    0.2584];
    DCM.Ep.D = zeros(DCM.n, DCM.n, 0);
    DCM.Ep.transit = [-0.0007;  -0.0918;  -0.0097;   0.0759;  -0.0373;  -0.0622;  -0.0058];
    DCM.Ep.decay   = [-0.0424;  -0.0614;   0.0129;   0.0727;   0.0077;  -0.0769;  -0.0010];
    DCM.Ep.epsilon = 0.0462;
end

%Input definition
u1 = int32(rand(floor(DCM.v*input_density), 1) * (DCM.v-1) + 1);
u2 = int32(rand(floor(DCM.v*input_density*0.5), 1) * (DCM.v-1) + 1);
u = zeros(DCM.v*microtime, uN);
for i = 1:length(u1)
    ui = u1(i);
    u((ui*microtime):((ui+1)*microtime-1),1) = 1;
end
for i = 1:length(u2)
    ui = u2(i);
    u((ui*microtime):((ui+1)*microtime-1),2) = 1;
end
u = u(1:DCM.v*microtime,:);

%DCM model creation, DO NOT CHANGE ANYTHING BELOW
DCM.Y.dt = TR;
for i = 1:DCM.n
    DCM.Y.name{i} = strcat('R', num2str(i));
end

DCM.U.dt = DCM.Y.dt / microtime;
DCM.U.u = u;
for i = 1:uN
    DCM.U.name{i} = strcat('Stim_', num2str(i));
end

DCM.delays = repmat(DCM.Y.dt/2, DCM.n, 1);
DCM.TE = 0.04;

DCM.options.nonlinear = 0;
DCM.options.two_state = 0;
DCM.options.stochastic = 0;
DCM.options.nograph = 1;

DCM.a = ~~DCM.Ep.A * 1;
DCM.b = ~~DCM.Ep.B * 1;
DCM.c = ~~DCM.Ep.C * 1;
DCM.d = zeros(DCM.n, DCM.n, 0);

syn_model = DCM;

spm_dcm_generate(syn_model, 1, 0);

copyfile(strcat('DCM-', date, '.mat'), strcat('DCM-n', int2str(DCM.n), '-v', int2str(DCM.v), '-matlab.mat'));
movefile(strcat('DCM-', date, '.mat'), strcat('DCM-n', int2str(DCM.n), '-v', int2str(DCM.v), '-R.mat'));
